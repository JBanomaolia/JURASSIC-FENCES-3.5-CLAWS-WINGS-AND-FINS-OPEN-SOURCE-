// scripts/main.js

// Importacion de entidades
import "./entidades/cielo.js";
import "./entidades/mar.js";
import "./entidades/tierra.js";

// Importación de Sistemas
import "./sistemas/operaciones.js";
import "./sistemas/economia.js";
import "./sistemas/red_electric.js";
import "./sistemas/seguridad.js";
import "./sistemas/builder.js";
import "./sistemas/structures.js";
import "./sistemas/demolicion.js";
import "./sistemas/bloques_extras.js";
import "./sistemas/debug.js";
import "./sistemas/logrosManager.js";
import "./sistemas/worldedit.js";

// Importación de decoracion
import "./decoracion/sign.js";
import "./decoracion/stairs.js";

// Registro obligatorio de Custom Components para bloques 1.21.60+
import { system } from "@minecraft/server";
import { abrirMenuMaestroVallas } from "./sistemas/builder.js";

system.beforeEvents.startup.subscribe((data) => {
    const customComponents = [
        "ap:fence",
        "ap:poste",
        "ap:base",
        "ap:barrera",
        "ap:sign",
        "ap:light_jw",
        "ap:info",
        "ap:indicator",
        "ap:registro_interact"
    ];

    for (const compId of customComponents) {
        data.blockComponentRegistry.registerCustomComponent(compId, {
            onPlayerInteract(event) {
                const { player, block } = event;
                if (!player || !block) return;

                const inventory = player.getComponent("inventory")?.container;
                const itemEnMano = inventory?.getItem(player.selectedSlotIndex);

                if (itemEnMano?.typeId === "ap:control_vallas" || itemEnMano?.typeId === "ap:control_remoto") {
                    const id = block.typeId;
                    const esBase = compId === "ap:base" || id.includes("base_n") || id.includes("base_valla");
                    const esBarrera = compId === "ap:barrera" || block.hasTag("ap:builder_conductual") || id.includes("barrera");

                    if (esBase || esBarrera || compId === "ap:fence" || compId === "ap:poste") {
                        abrirMenuMaestroVallas(player, block, esBase, esBarrera);
                    }
                }
            }
        });
    }

    const itemComponents = ["ap:builder", "ap:info", "ap:panel_handler"];
    for (const itemCompId of itemComponents) {
        data.itemComponentRegistry.registerCustomComponent(itemCompId, {
            onUseOn(event) {}
        });
    }
});
