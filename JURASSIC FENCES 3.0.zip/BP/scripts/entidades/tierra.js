import { world, system, EquipmentSlot, ItemStack } from "@minecraft/server";
import { ActionFormData } from "@minecraft/server-ui";

const VEHICULOS_TERRESTRES = [
  "ap:fertech",
  "ap:fertech_din",
  "ap:fertech_fishing_and_wildlife",
  "ap:fertech_jw",
  "ap:camion_recursos",
  "ap:jurassic_truck"
];

const TICKS_POR_REDSTONE = 2400; 
const CAPACIDAD_MAXIMA_TICKS = 48000;

// Registro de estado para cada conductor
const jugadoresEnVehiculo = new Map();

world.afterEvents.playerLeave.subscribe((event) => {
  jugadoresEnVehiculo.delete(event.playerId);
});

function obtenerAlturaSuelo(dim, x, baseY, z) {
  for (let yOffset = 2; yOffset >= -2; yOffset--) {
    try {
      const b = dim.getBlock({ x: Math.floor(x), y: Math.floor(baseY + yOffset), z: Math.floor(z) });
      if (b && !b.isAir && !b.isLiquid) {
        return b.location.y + 1; 
      }
    } catch (e) {}
  }
  return baseY;
}

// =====================================================================
// 1. DINÁMICA DE INCLINACIÓN, COMBUSTIBLE, INVISIBILIDAD Y MANO OCULTA
// =====================================================================
system.runInterval(() => {
  try {
    const time = world.getTimeOfDay();
    const esDeNoche = time >= 13000 && time <= 23000;

    for (const player of world.getAllPlayers()) {
      if (!player || !player.isValid()) continue;

      const ridingComponent = player.getComponent("minecraft:riding");
      const vehicle = ridingComponent?.entityRidingOn;
      const estaEnVehiculo = vehicle && vehicle.isValid() && VEHICULOS_TERRESTRES.includes(vehicle.typeId);
      const estabaEnVehiculo = jugadoresEnVehiculo.has(player.id);

      // --- ENTRADA AL VEHÍCULO ---
      if (estaEnVehiculo && !estabaEnVehiculo) {
        const equippable = player.getComponent("equippable");
        const itemMano = equippable?.getEquipment(EquipmentSlot.Mainhand);

        // Guardar copia del ítem actual en mano y ocultarlo
        jugadoresEnVehiculo.set(player.id, {
          itemGuardado: itemMano ? itemMano.clone() : undefined
        });

        if (itemMano) {
          equippable?.setEquipment(EquipmentSlot.Mainhand, undefined);
        }
      }

      // --- SALIDA DEL VEHÍCULO ---
      if (!estaEnVehiculo && estabaEnVehiculo) {
        // 1. Quitar invisibilidad de forma inmediata
        try {
          player.removeEffect("invisibility");
        } catch (e) {}

        // 2. Restaurar el ítem guardado a la mano principal
        const datos = jugadoresEnVehiculo.get(player.id);
        if (datos?.itemGuardado) {
          const equippable = player.getComponent("equippable");
          const manoActual = equippable?.getEquipment(EquipmentSlot.Mainhand);

          if (!manoActual) {
            equippable?.setEquipment(EquipmentSlot.Mainhand, datos.itemGuardado);
          } else {
            const inv = player.getComponent("minecraft:inventory")?.container;
            if (inv) inv.addItem(datos.itemGuardado);
          }
        }

        jugadoresEnVehiculo.delete(player.id);
        continue;
      }

      // --- DURANTE LA CONDUCCIÓN ---
      if (estaEnVehiculo) {
        // Mantener invisibilidad activa
        player.addEffect("invisibility", 40, { showParticles: false });

        // Guardar cualquier nuevo ítem sostenido en el inventario para mantener la mano limpia (excepto la llave y redstone)
        const equippable = player.getComponent("equippable");
        const itemManoActual = equippable?.getEquipment(EquipmentSlot.Mainhand);

        if (itemManoActual && itemManoActual.typeId !== "ap:llave_vehiculo" && itemManoActual.typeId !== "minecraft:redstone") {
          const inv = player.getComponent("minecraft:inventory")?.container;
          if (inv) {
            inv.addItem(itemManoActual.clone());
            equippable.setEquipment(EquipmentSlot.Mainhand, undefined);
          }
        }

        // Sistema de Combustible
        let combustibleActual = vehicle.getDynamicProperty("combustible_ticks") ?? 0;
        const velocidadVel = vehicle.getVelocity();
        const enMovimiento = Math.abs(velocidadVel.x) > 0.05 || Math.abs(velocidadVel.z) > 0.05;

        if (enMovimiento) {
          if (combustibleActual > 0) {
            combustibleActual -= 1;
            vehicle.setDynamicProperty("combustible_ticks", combustibleActual);

            if (system.currentTick % 20 === 0) {
              const porcentaje = Math.floor((combustibleActual / CAPACIDAD_MAXIMA_TICKS) * 100);
              const cuadrosLlenos = Math.floor(porcentaje / 10);
              const barra = "§a" + "■".repeat(cuadrosLlenos) + "§7" + "□".repeat(10 - cuadrosLlenos);
              player.onScreenDisplay.setActionBar(`§6⛽ COMBUSTIBLE: ${barra} §f${porcentaje}%`);
            }
          } else {
            player.onScreenDisplay.setActionBar("§c⚠️ SIN COMBUSTIBLE. Usa Polvo de Redstone.");
            vehicle.applyImpulse({ x: 0, y: velocidadVel.y, z: 0 }); 
            const rot = vehicle.getRotation();
            const rad = (rot.y + 180) * (Math.PI / 180);
            vehicle.applyImpulse({ x: Math.sin(rad) * 0.05, y: 0, z: Math.cos(rad) * 0.05 });
            continue; 
          }
        } else if (system.currentTick % 40 === 0) {
            const porcentaje = Math.floor((combustibleActual / CAPACIDAD_MAXIMA_TICKS) * 100);
            player.onScreenDisplay.setActionBar(`§eMotor en pausa. Combustible: ${porcentaje}%`);
        }

        // Cálculo de Inclinación Terrestre
        const dim = vehicle.dimension;
        const vehicleRot = vehicle.getRotation();
        const yawRad = (vehicleRot.y + 90) * (Math.PI / 180);
        
        const frontX = vehicle.location.x + Math.cos(yawRad) * 1.5;
        const frontZ = vehicle.location.z + Math.sin(yawRad) * 1.5;
        const alturaFrente = obtenerAlturaSuelo(dim, frontX, vehicle.location.y, frontZ);

        const backX = vehicle.location.x - Math.cos(yawRad) * 1.5;
        const backZ = vehicle.location.z - Math.sin(yawRad) * 1.5;
        const alturaAtras = obtenerAlturaSuelo(dim, backX, vehicle.location.y, backZ);

        const difAltura = alturaFrente - alturaAtras;
        let targetPitch = 0;
        
        if (difAltura > 1.2) targetPitch = -45;
        else if (difAltura > 0.2) targetPitch = -22.5;
        else if (difAltura < -1.2) targetPitch = 45;
        else if (difAltura < -0.2) targetPitch = 22.5;

        const smoothedPitch = vehicleRot.x + (targetPitch - vehicleRot.x) * 0.15;
        vehicle.setProperty("ap:pitch", smoothedPitch);

        if (esDeNoche && combustibleActual > 0) {
          player.addEffect("night_vision", 220, { showParticles: false });
        }
      }
    }
  } catch (err) {}
}, 1);

// =====================================================================
// 2. EVENTOS DE USO DE ÍTEMS Y GUI
// =====================================================================
world.afterEvents.itemUse.subscribe((event) => {
  const { source: player, itemStack: item } = event;
  if (!player || !player.isValid()) return;

  const ridingComponent = player.getComponent("minecraft:riding");
  const vehicle = ridingComponent?.entityRidingOn;

  if (vehicle && vehicle.isValid() && VEHICULOS_TERRESTRES.includes(vehicle.typeId)) {
    if (item?.typeId === "ap:llave_vehiculo") {
      vehicle.dimension.playSound("random.horn", vehicle.location, { volume: 1.0, pitch: 1.0 });
      player.onScreenDisplay.setActionBar("§e*CLAXON ACTIVADO*");
      return;
    }

    if (item?.typeId === "minecraft:redstone") {
      let combustibleActual = vehicle.getDynamicProperty("combustible_ticks") ?? 0;
      if (combustibleActual >= CAPACIDAD_MAXIMA_TICKS) {
        player.onScreenDisplay.setActionBar("§aTanque LLENO (100%).");
        return;
      }
      const equippable = player.getComponent("equippable");
      const newItem = item.amount > 1 ? new ItemStack("minecraft:redstone", item.amount - 1) : undefined;
      equippable.setEquipment(EquipmentSlot.Mainhand, newItem);
      combustibleActual = Math.min(combustibleActual + TICKS_POR_REDSTONE, CAPACIDAD_MAXIMA_TICKS);
      vehicle.setDynamicProperty("combustible_ticks", combustibleActual);
      player.playSound("random.orb", { pitch: 1.2 });
      vehicle.dimension.spawnParticle("minecraft:redstone_ore_dust_particle", { x: vehicle.location.x, y: vehicle.location.y + 1, z: vehicle.location.z });
    }
  }
});

// =====================================================================
// 3. LÓGICA DEL ALIMENTADOR (ap:feeder)
// =====================================================================
world.afterEvents.playerInteractWithEntity.subscribe((event) => {
  const { player, target } = event;
  if (player && target?.typeId === "ap:feeder") {
    system.run(() => abrirInterfazAlimentador(player, target));
  }
});

function abrirInterfazAlimentador(player, feeder) {
  const form = new ActionFormData()
    .title("Alimentador Automático")
    .body("Selecciona la ración a dispensar.")
    .button("Dispensar Carne (Carnívoros)")
    .button("Dispensar Vegetales (Herbívoros)")
    .button("Dispensar Peces (Piscívoros)")
    .button("Cerrar Panel");

  system.runTimeout(() => {
    form.show(player).then((res) => {
      if (res.canceled || res.selection === 3) return;
      if (res.selection === 0) dispensarCarne(feeder, player);
      if (res.selection === 1) dispensarVegetales(feeder, player);
      if (res.selection === 2) dispensarPeces(feeder, player);
    }).catch(() => {});
  }, 10);
}

system.afterEvents.scriptEventReceive.subscribe((event) => {
  if (event.id === "ap:feeder") {
      const feeder = event.sourceEntity;
      if (!feeder || !feeder.isValid()) return;
      
      if (event.message === "carnivore") dispensarCarne(feeder);
      if (event.message === "herbivore") dispensarVegetales(feeder);
      if (event.message === "picivore") dispensarPeces(feeder);
  }
});

function dispensarCarne(feeder, player = null) {
  const dim = feeder.dimension;
  const loc = feeder.location;
  
  const cabra = dim.spawnEntity("minecraft:goat", { x: loc.x + 1.5, y: loc.y + 1, z: loc.z });
  const oveja = dim.spawnEntity("minecraft:sheep", { x: loc.x - 1.5, y: loc.y + 1, z: loc.z });
  
  cabra.addTag("presa_alimentador");
  oveja.addTag("presa_alimentador");

  dim.playSound("random.dispense", loc);
  if(player) player.onScreenDisplay.setActionBar("§a[Alimentador] Carne dispensada.");
}

function dispensarVegetales(feeder, player = null) {
  const dim = feeder.dimension;
  const loc = feeder.location;
  const bloques = ["minecraft:hay_block", "minecraft:tallgrass", "minecraft:sweet_berry_bush"];
  
  for(let i = 0; i < 5; i++) {
      const targetX = loc.x + (Math.random() * 20 - 10);
      const targetZ = loc.z + (Math.random() * 20 - 10);
      const targetY = obtenerAlturaSuelo(dim, targetX, loc.y, targetZ);
      
      try {
          const bloque = dim.getBlock({ x: targetX, y: targetY, z: targetZ });
          if(bloque && bloque.isAir) {
              const aleatorio = bloques[Math.floor(Math.random() * bloques.length)];
              bloque.setType(aleatorio);
          }
      } catch(e) {}
  }
  dim.playSound("random.dispense", loc);
  if(player) player.onScreenDisplay.setActionBar("§a[Alimentador] Vegetales dispensados.");
}

function dispensarPeces(feeder, player = null) {
  const dim = feeder.dimension;
  const loc = feeder.location;
  for(let i = 0; i < 4; i++) {
      dim.spawnEntity("minecraft:tropicalfish", { x: loc.x, y: loc.y + 1, z: loc.z });
  }
  dim.playSound("random.dispense", loc);
  if(player) player.onScreenDisplay.setActionBar("§a[Alimentador] Peces dispensados.");
}

world.afterEvents.entityDie.subscribe((event) => {
  const { deadEntity } = event;
  if (deadEntity.hasTag("presa_alimentador")) {
      const loc = deadEntity.location;
      const dim = deadEntity.dimension;
      
      system.runTimeout(() => {
          try {
             dim.runCommand(`kill @e[type=item,x=${loc.x},y=${loc.y},z=${loc.z},r=4]`);
          } catch(e) {}
      }, 2);
  }
});
