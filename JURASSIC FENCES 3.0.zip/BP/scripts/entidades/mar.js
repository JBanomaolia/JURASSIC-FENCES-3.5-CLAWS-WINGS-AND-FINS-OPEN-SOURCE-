import { world, system } from "@minecraft/server";

const VEHICULOS_ACUATICOS = [
  "ap:submarino",
  "ap:lancha",
  "ap:barco_guardacostas"
];

system.runInterval(() => {
  try {
    for (const player of world.getAllPlayers()) {
      if (!player || !player.isValid()) continue;

      const ridingComponent = player.getComponent("minecraft:riding");
      const vehicle = ridingComponent?.entityRidingOn;

      const isRidingAcuatico = vehicle && vehicle.isValid() && VEHICULOS_ACUATICOS.includes(vehicle.typeId);

      if (isRidingAcuatico) {
        player.addEffect("water_breathing", 30, { showParticles: false });

        const pitch = typeof player.getRotation === "function" ? player.getRotation().x : 0;
        const currentVel = typeof vehicle.getVelocity === "function" ? vehicle.getVelocity() : { x: 0, y: 0, z: 0 };
        let targetVelY = 0.02;

        if (pitch < -20) targetVelY = 0.15;
        else if (pitch > 20) targetVelY = -0.15;

        const diffY = targetVelY - (currentVel.y ?? 0);
        if (Math.abs(diffY) > 0.01) {
          try {
            if (typeof vehicle.applyImpulse === "function") {
              vehicle.applyImpulse({ x: 0, y: diffY, z: 0 });
            }
          } catch (e) { }
        }
      }
    }
  } catch (globalError) {
    console.warn("[JF 3.0] Error en mar.js: " + globalError);
  }
}, 1);
