import { world, system, ItemStack, ItemLockMode } from "@minecraft/server";
import { ActionFormData } from "@minecraft/server-ui";

const AERONAVES_VALIDAS = [
  "ap:heli_din",
  "ap:tr_din",
  "ap:airplane_jp3"
];

// Remoción nativa de ítems sin usar comandos
function removerItemDelInventario(player, typeId) {
  try {
    const inventory = player.getComponent("minecraft:inventory")?.container;
    if (!inventory) return;

    for (let i = 0; i < inventory.size; i++) {
      const item = inventory.getItem(i);
      if (item && item.typeId === typeId) {
        inventory.setItem(i, undefined);
      }
    }
  } catch (e) { }
}

// Motor de vuelo e inventario sincronizado
system.runInterval(() => {
  try {
    for (const player of world.getAllPlayers()) {
      if (!player || !player.isValid()) continue;

      const ridingComponent = player.getComponent("minecraft:riding");
      const vehicle = ridingComponent?.entityRidingOn;

      const isRidingTrDin = vehicle && vehicle.isValid() && vehicle.typeId === "ap:tr_din";
      const isRidingAeronave = vehicle && vehicle.isValid() && AERONAVES_VALIDAS.includes(vehicle.typeId);
      const hasTrackingTag = player.hasTag("en_helicoptero");

      // 1. Control de Gancho Táctico (TR-DIN)
      if (isRidingTrDin && !hasTrackingTag) {
        player.addTag("en_helicoptero");
        darControlGancho(player);
        player.onScreenDisplay?.setActionBar("§6[Sistema] Control de gancho enlazado.");
        player.playSound("random.pop");
      } 
      else if (!isRidingTrDin && hasTrackingTag) {
        player.removeTag("en_helicoptero");
        removerItemDelInventario(player, "ap:hook_control");
        player.onScreenDisplay?.setActionBar("§7[Sistema] Control de gancho desconectado.");
      }

      // 2. Motor de Elevación / Propulsión de Aeronaves
      if (isRidingAeronave) {
        const pitch = typeof player.getRotation === "function" ? player.getRotation().x : 0;
        const currentVel = typeof vehicle.getVelocity === "function" ? vehicle.getVelocity() : { x: 0, y: 0, z: 0 };
        let targetVelY = 0.05;

        if (pitch < -15) targetVelY = 0.22;
        else if (pitch > 15) targetVelY = -0.22;

        const diffY = targetVelY - (currentVel.y ?? 0);
        if (Math.abs(diffY) > 0.01) {
          try {
            if (typeof vehicle.applyImpulse === "function") {
              vehicle.applyImpulse({ x: 0, y: diffY, z: 0 });
            }
          } catch (e) { }
        }

        player.addEffect("invisibility", 15, { showParticles: false });
      }
    }
  } catch (globalError) {
    console.warn("[JF 3.0] Error en cielo.js: " + globalError);
  }
}, 1);

function darControlGancho(player) {
  try {
    const inventory = player.getComponent("minecraft:inventory")?.container;
    if (!inventory) return;

    const hookItem = new ItemStack("ap:hook_control", 1);
    try {
      hookItem.lockMode = ItemLockMode.slot;
    } catch (e) { }

    inventory.addItem(hookItem);
  } catch (e) { }
}

// Panel interactivo de liberación
world.afterEvents.itemUse.subscribe((event) => {
  const player = event.source;
  const item = event.itemStack;

  if (!player || !player.isValid() || item?.typeId !== "ap:hook_control") return;

  const ridingComponent = player.getComponent("minecraft:riding");
  const vehiculo = ridingComponent?.entityRidingOn;

  if (vehiculo && vehiculo.isValid() && vehiculo.typeId === "ap:tr_din") {
    const form = new ActionFormData()
      .title("Panel de Control del Gancho")
      .body("Sistema de transporte táctico de dinosaurios activo.\n¿Confirmar liberación de la jaula?")
      .button("Soltar Jaula")
      .button("Cancelar Operación");

    form.show(player).then((res) => {
      if (res.canceled || res.selection !== 0) return;

      const jaulas = vehiculo.dimension.getEntities({
        type: "ap:jaula",
        location: vehiculo.location,
        maxDistance: 20
      });

      if (jaulas.length === 0) {
        player.sendMessage("§c[Táctico] No se encontró ninguna jaula enlazada cercana.");
        player.playSound("note.bass");
        return;
      }

      for (const jaula of jaulas) {
        if (jaula.isValid()) jaula.remove();
      }

      const inv = player.getComponent("minecraft:inventory")?.container;
      if (inv) {
        inv.addItem(new ItemStack("ap:jaula_spawn_egg", 1));
      }

      player.onScreenDisplay?.setActionBar("§c[Alerta] ¡Jaula retirada del gancho!");
      player.sendMessage("§a[Táctico] §fJaula liberada y recuperada en el inventario.");
      player.playSound("random.orb");
    }).catch((e) => console.warn(e));
  } else {
    player.sendMessage("§c[Táctico] Debes estar piloteando el helicóptero TR-DIN para usar el gancho.");
  }
});
