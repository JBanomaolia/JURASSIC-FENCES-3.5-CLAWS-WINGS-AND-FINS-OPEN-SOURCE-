import { world, system, BlockPermutation } from "@minecraft/server";

const DIMENSIONES = ["overworld", "nether", "the_end"];

// --- REGISTRO DE COMPONENTES DE BLOQUE ---
world.beforeEvents.worldInitialize.subscribe((initEvent) => {

  // 1. ap:sign - Componente pasivo con controladores neutros
  try {
    initEvent.blockComponentRegistry.registerCustomComponent("ap:sign", {
      onPlayerInteract: () => {},
      onPlace: () => {},
      onStepOn: () => {},
      onStepOff: () => {}
    });
  } catch (e) {
    console.warn("[JF 3.0] Error registrando componente ap:sign: " + e);
  }

  // 2. ap:light_jw - Construcción automática de lámparas
  try {
    initEvent.blockComponentRegistry.registerCustomComponent("ap:light_jw", {
      onPlace: (ev) => {
        const { block, dimension } = ev;
        if (!block || !block.isValid()) return;

        const typeId = block.typeId;
        const baseStates = block.permutation.getAllStates();

        system.run(() => {
          try {
            if (!block.isValid()) return;

            // Bloque 1 (Base) - Estado 0
            const statesBase = { ...baseStates, "ap:sign": 0 };
            block.setPermutation(BlockPermutation.resolve(typeId, statesBase));

            // Bloque 2 - Estado 2
            const b2 = dimension.getBlock({ x: block.x, y: block.y + 1, z: block.z });
            if (b2 && (b2.isAir || b2.isLiquid)) {
              const statesMiddle1 = { ...baseStates, "ap:sign": 2 };
              b2.setPermutation(BlockPermutation.resolve(typeId, statesMiddle1));
            }

            // Bloque 3 - Estado 2
            const b3 = dimension.getBlock({ x: block.x, y: block.y + 2, z: block.z });
            if (b3 && (b3.isAir || b3.isLiquid)) {
              const statesMiddle2 = { ...baseStates, "ap:sign": 2 };
              b3.setPermutation(BlockPermutation.resolve(typeId, statesMiddle2));
            }

            // Bloque 4 (Cima) - Estado 3
            const b4 = dimension.getBlock({ x: block.x, y: block.y + 3, z: block.z });
            if (b4 && (b4.isAir || b4.isLiquid)) {
              const statesTop = { ...baseStates, "ap:sign": 3 };
              b4.setPermutation(BlockPermutation.resolve(typeId, statesTop));
            }
          } catch (err) {
            console.warn("[JF 3.0] Error al generar la lámpara: " + err);
          }
        });
      }
    });
  } catch (e) {
    console.warn("[JF 3.0] Error registrando componente ap:light_jw: " + e);
  }

  // 3. ap:silla - Sistema para sentarse en bancas
  try {
    initEvent.blockComponentRegistry.registerCustomComponent("ap:silla", {
      onPlayerInteract: (ev) => {
        const { block, player, dimension } = ev;
        if (!player || !player.isValid() || !block || !block.isValid()) return;

        system.run(() => {
          try {
            if (!block.isValid() || !player.isValid()) return;

            // Ajuste de coordenadas según la dirección cardinal
            let dir = "north";
            try {
              dir = block.permutation.getState("minecraft:cardinal_direction") || "north";
            } catch (e) { }

            let ox = 0, oz = -0.2;

            if (dir === "south") oz = 0.2;
            if (dir === "east") { ox = 0.2; oz = 0; }
            if (dir === "west") { ox = -0.2; oz = 0; }

            const spawnLoc = {
              x: block.x + 0.5 + ox,
              y: block.y + 0.5,
              z: block.z + 0.5 + oz
            };

            const asiento = dimension.spawnEntity("ap:asiento", spawnLoc);

            system.runTimeout(() => {
              if (!asiento || !asiento.isValid() || !player || !player.isValid()) {
                if (asiento && asiento.isValid()) asiento.remove();
                return;
              }

              const rideable = asiento.getComponent("minecraft:rideable");
              if (rideable) {
                rideable.addRider(player);
              }
            }, 2);

          } catch (err) {
            console.warn("[JF 3.0] Error en la silla: " + err);
          }
        });
      }
    });
  } catch (e) {
    console.warn("[JF 3.0] Error registrando componente ap:silla: " + e);
  }
});

// --- LIMPIEZA AUTOMÁTICA DE ASIENTOS VACÍOS MULTI-DIMENSIÓN ---
system.runInterval(() => {
  for (const dimId of DIMENSIONES) {
    try {
      const dimension = world.getDimension(dimId);
      if (!dimension) continue;

      const asientos = dimension.getEntities({ type: "ap:asiento" });

      for (const asiento of asientos) {
        if (!asiento || !asiento.isValid()) continue;

        const rideable = asiento.getComponent("minecraft:rideable");

        // Elimina la entidad si no hay nadie sentado en ella
        if (rideable && rideable.getRiders().length === 0) {
          asiento.remove();
        }
      }
    } catch (err) { }
  }
}, 40);
