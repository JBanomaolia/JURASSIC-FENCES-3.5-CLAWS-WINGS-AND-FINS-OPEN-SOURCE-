import { world, system } from "@minecraft/server";

// ==========================================
// 🧠 LÓGICA DE DETECCIÓN DE ESQUINAS
// ==========================================

function getStairShape(block) {
  const perm = block.permutation;
  const myDir = perm.getState("minecraft:cardinal_direction");
  const myHalf = perm.getState("minecraft:vertical_half");

  if (!myDir || !myHalf) return "recta";

  // 1. Mapeamos qué significa "frente, atrás, izquierda y derecha" según nuestra rotación
  let frontDir, backDir, leftDir, rightDir;
  switch (myDir) {
    case "north": frontDir = "north"; backDir = "south"; leftDir = "west"; rightDir = "east"; break;
    case "south": frontDir = "south"; backDir = "north"; leftDir = "east"; rightDir = "west"; break;
    case "east": frontDir = "east"; backDir = "west"; leftDir = "north"; rightDir = "south"; break;
    case "west": frontDir = "west"; backDir = "east"; leftDir = "south"; rightDir = "north"; break;
  }

  // Función auxiliar para obtener el bloque vecino de forma segura
  const getNeighbor = (dir) => {
    switch (dir) {
      case "north": return block.north();
      case "south": return block.south();
      case "east": return block.east();
      case "west": return block.west();
      default: return undefined;
    }
  };

  // 2. Comprobar ESQUINAS INTERNAS (revisando el bloque de atrás)
  const backBlock = getNeighbor(backDir);
  if (backBlock && backBlock.typeId.includes("stairs")) {
    const backPerm = backBlock.permutation;
    if (backPerm.getState("minecraft:vertical_half") === myHalf) {
      const backBlockDir = backPerm.getState("minecraft:cardinal_direction");
      if (backBlockDir === leftDir) return "interna_left";
      if (backBlockDir === rightDir) return "interna_right";
    }
  }

  // 3. Comprobar ESQUINAS EXTERNAS (revisando el bloque de enfrente)
  const frontBlock = getNeighbor(frontDir);
  if (frontBlock && frontBlock.typeId.includes("stairs")) {
    const frontPerm = frontBlock.permutation;
    if (frontPerm.getState("minecraft:vertical_half") === myHalf) {
      const frontBlockDir = frontPerm.getState("minecraft:cardinal_direction");
      if (frontBlockDir === leftDir) return "externa_left";
      if (frontBlockDir === rightDir) return "externa_right";
    }
  }

  // 4. Si no coincide con ninguna esquina, mantener recta
  return "recta";
}

// ==========================================
// 🔄 FUNCIONES DE ACTUALIZACIÓN
// ==========================================

function updateStair(block) {
  if (!block || !block.isValid() || !block.typeId.includes("stairs")) return;

  const currentShape = block.permutation.getState("ap:forma_escalon");
  if (currentShape === undefined) return; // Evita errores si el bloque no tiene la propiedad

  const newShape = getStairShape(block);

  // Solo actualizamos si la forma calculada es distinta a la actual (evita loops infinitos)
  if (currentShape !== newShape) {
    block.setPermutation(block.permutation.withState("ap:forma_escalon", newShape));
  }
}

function updateNeighborsOfLocation(dimension, location) {
  const offsets = [
    { x: 0, y: 0, z: -1 }, // north
    { x: 0, y: 0, z: 1 },  // south
    { x: 1, y: 0, z: 0 },  // east
    { x: -1, y: 0, z: 0 }  // west
  ];

  for (const offset of offsets) {
    const neighbor = dimension.getBlock({
      x: location.x + offset.x,
      y: location.y + offset.y,
      z: location.z + offset.z
    });

    // Si el vecino es un escalón, forzamos a que recalcule su forma
    if (neighbor && neighbor.typeId.includes("stairs")) {
      updateStair(neighbor);
    }
  }
}

// ==========================================
// 🚀 REGISTRO DEL COMPONENTE PERSONALIZADO
// ==========================================

world.beforeEvents.worldInitialize.subscribe((initEvent) => {
  initEvent.blockComponentRegistry.registerCustomComponent("ap:stairs", {

    onPlace: (event) => {
      const block = event.block;

      // Usamos system.run para ejecutar la lógica en el siguiente tick (frame) del juego.
      // Esto asegura que el bloque esté 100% colocado en el mundo antes de medir sus vecinos.
      system.run(() => {
        if (block.isValid()) {
          updateStair(block); // Actualiza la forma de este escalón
          updateNeighborsOfLocation(block.dimension, block.location); // Actualiza los escalones vecinos
        }
      });
    },

    onPlayerDestroy: (event) => {
      const dimension = event.dimension;
      const location = event.block.location;

      // Cuando un jugador rompe el escalón, actualizamos a los vecinos en el siguiente tick, 
      // cuando el bloque roto ya haya desaparecido físicamente.
      system.run(() => {
        updateNeighborsOfLocation(dimension, location);
      });
    }

  });
});
