import { world, system } from "@minecraft/server";
import { ModalFormData } from "@minecraft/server-ui";

// Guardado de configuración y selecciones por jugador
const configJugadores = new Map();
const ultimasPosiciones = new Map();
const seleccionesFill = new Map(); // Guardará { posA, posB } para el modo relleno

const ESTRUCTURAS = [
  "world/grass_block",
  "world/stone",
  "world/sand",
  "world/water"
];

// Limpieza de memoria cuando el jugador sale del mundo
world.afterEvents.playerLeave.subscribe((event) => {
  configJugadores.delete(event.playerId);
  ultimasPosiciones.delete(event.playerId);
  seleccionesFill.delete(event.playerId);
});

// =====================================================================
// 1. PREVENCIÓN DE RUPTURA E INTERACCIÓN CON BLOQUES
// =====================================================================
world.beforeEvents.playerBreakBlock.subscribe((event) => {
  const { itemStack } = event;
  if (itemStack?.typeId === "ap:world_edit") {
    event.cancel = true; // Evita romper el bloque al mantener pulsado
  }
});

world.beforeEvents.playerInteractWithBlock.subscribe((event) => {
  const { itemStack } = event;
  if (itemStack?.typeId === "ap:world_edit") {
    event.cancel = true; // Cancela la interacción nativa del bloque
  }
});

// =====================================================================
// 2. INTERACCIÓN CON BLOQUES (USO DIRECTO CON EL ÍTEM)
// =====================================================================
world.beforeEvents.itemUseOn.subscribe((event) => {
  const { source: player, itemStack, block } = event;

  if (itemStack?.typeId === "ap:world_edit") {
    event.cancel = true;

    system.run(() => {
      const estaAgachado = player.isSneaking;
      const estaVolando = player.isFlying ?? false;

      // Si está agachado Y NO está volando -> Abre Menú de Configuración
      if (estaAgachado && !estaVolando) {
        abrirMenuWorldEdit(player);
      } else {
        // Usa la posición EXACTA del bloque tocado
        procesarAccionConPosicion(player, block.location);
      }
    });
  }
});

// Intercepción para uso en el aire (Raycast al bloque objetivo)
world.beforeEvents.itemUse.subscribe((event) => {
  const { source: player, itemStack } = event;

  if (itemStack?.typeId === "ap:world_edit") {
    event.cancel = true;

    system.run(() => {
      const estaAgachado = player.isSneaking;
      const estaVolando = player.isFlying ?? false;

      if (estaAgachado && !estaVolando) {
        abrirMenuWorldEdit(player);
      } else {
        const ray = player.getBlockFromRay({ maxDistance: 20 });
        if (ray?.block) {
          procesarAccionConPosicion(player, ray.block.location);
        }
      }
    });
  }
});

// =====================================================================
// 3. MENÚ PRINCIPAL DE WORLD EDIT
// =====================================================================
function abrirMenuWorldEdit(player) {
  const config = configJugadores.get(player.id) || {
    encendido: false,
    modo: 0,
    remplazar: false,
    borrar: false
  };

  new ModalFormData()
    .title("WorldEdit AP")
    .toggle("Estado (Encendido/Apagado)", config.encendido)
    .dropdown("Modo de Estructura / Herramienta", [
      "Pasto (Grass)",
      "Piedra (Stone)",
      "Arena (Sand)",
      "Agua (Water)",
      "Leñador (Lumberjack)",
      "Modo Relleno (Fill A -> B)"
    ], config.modo)
    .toggle("Reemplazar solo bloques existentes", config.remplazar)
    .toggle("Modo Borrar (Air)", config.borrar)
    .show(player)
    .then((res) => {
      if (res.canceled) return;

      const [encendido, modo, remplazar, borrar] = res.formValues;
      configJugadores.set(player.id, { encendido, modo, remplazar, borrar });

      if (modo === 5) {
        seleccionesFill.set(player.id, { posA: null, posB: null });
        player.sendMessage("§e[WorldEdit] Modo Relleno activado. Toca un bloque para marcar el Punto A.");
      }

      player.sendMessage("§a[WorldEdit] Configuración guardada correctamente.");
      player.playSound("random.orb");
    })
    .catch((e) => console.warn(e));
}

// =====================================================================
// 4. PROCESAMIENTO DE ACCIONES CON POSICIÓN EXACTA
// =====================================================================
function procesarAccionConPosicion(player, posTarget) {
  const config = configJugadores.get(player.id);
  if (!config || !config.encendido) return;

  // --- MODO 5: RELLENO (FILL A -> B) ---
  if (config.modo === 5) {
    manejarSeleccionFill(player, posTarget);
    return;
  }

  // Prevención de spam en la misma coordenada
  const posKey = `${posTarget.x},${posTarget.y},${posTarget.z}`;
  if (ultimasPosiciones.get(player.id) === posKey) return;
  ultimasPosiciones.set(player.id, posKey);

  // --- MODO 4: LEÑADOR ---
  if (config.modo === 4) {
    system.runJob(motorLumberjackAsync(player.dimension, posTarget));
  } 
  // --- MODOS 0 - 3: COLOCACIÓN DE ESTRUCTURA ---
  else {
    ejecutarColocacionEstructura(player, player.dimension, posTarget, config);
  }
}

// =====================================================================
// 5. SELECCIÓN Y MENÚ DE RELLENO (SIN ESTAR AGACHADO)
// =====================================================================
function manejarSeleccionFill(player, posTarget) {
  let sel = seleccionesFill.get(player.id) || { posA: null, posB: null };

  if (!sel.posA) {
    // Selección del Punto A exacta
    sel.posA = { x: posTarget.x, y: posTarget.y, z: posTarget.z };
    seleccionesFill.set(player.id, sel);
    player.sendMessage(`§a[WorldEdit] Punto A marcado en: (${posTarget.x}, ${posTarget.y}, ${posTarget.z})`);
    player.playSound("note.pling", { pitch: 1.2 });
  } else {
    // Selección del Punto B exacta y apertura inmediata del menú
    sel.posB = { x: posTarget.x, y: posTarget.y, z: posTarget.z };
    seleccionesFill.set(player.id, sel);
    player.sendMessage(`§a[WorldEdit] Punto B marcado en: (${posTarget.x}, ${posTarget.y}, ${posTarget.z})`);
    player.playSound("note.pling", { pitch: 1.6 });

    system.runTimeout(() => abrirInterfazRelleno(player), 3);
  }
}

function abrirInterfazRelleno(player) {
  const sel = seleccionesFill.get(player.id);
  if (!sel || !sel.posA || !sel.posB) return;

  new ModalFormData()
    .title("Modo Relleno")
    .textField("ID del bloque a rellenar (ej: grass_block, stone, dirt):", "grass_block", "grass_block")
    .dropdown("Acción a realizar:", [
      "1. Rellenar área (Confirmar)",
      "2. Volver a seleccionar puntos",
      "3. Cancelar todo"
    ], 0)
    .show(player)
    .then((res) => {
      if (res.canceled) return;

      const [inputBloque, opcion] = res.formValues;

      if (opcion === 0) {
        let blockId = inputBloque.trim();
        if (!blockId.includes(":")) {
          blockId = `minecraft:${blockId}`;
        }

        // Ejecuta el comando de relleno exacto entre el Punto A y el Punto B (Inclusivo)
        const command = `fill ${sel.posA.x} ${sel.posA.y} ${sel.posA.z} ${sel.posB.x} ${sel.posB.y} ${sel.posB.z} ${blockId}`;
        
        player.dimension.runCommandAsync(command)
          .then(() => {
            player.sendMessage(`§a[WorldEdit] Área rellenada con exito usando '${blockId}'.`);
            player.playSound("random.levelup");
          })
          .catch(() => {
            player.sendMessage(`§c[WorldEdit] Error al rellenar: Bloque invalido o área demasiado grande.`);
          });

        seleccionesFill.set(player.id, { posA: null, posB: null });

      } else if (opcion === 1) {
        seleccionesFill.set(player.id, { posA: null, posB: null });
        player.sendMessage("§e[WorldEdit] Selección reiniciada. Toca un bloque para el Punto A.");
        player.playSound("random.pop");

      } else if (opcion === 2) {
        seleccionesFill.set(player.id, { posA: null, posB: null });
        player.sendMessage("§c[WorldEdit] Relleno cancelado.");
        player.playSound("random.pop");
      }
    })
    .catch((e) => console.warn(e));
}

// =====================================================================
// 6. COLOCACIÓN DE ESTRUCTURAS CENTRADAS
// =====================================================================
function ejecutarColocacionEstructura(player, dimension, centro, config) {
  try {
    const bloqueActual = dimension.getBlock(centro);

    if (config.remplazar && (!bloqueActual || bloqueActual.typeId === "minecraft:air" || bloqueActual.isAir)) {
      return;
    }

    const estructuraId = config.borrar ? "world/air" : ESTRUCTURAS[config.modo];
    const rotY = player.getRotation().y;
    let rotacionStr = "0_degrees";

    if (rotY >= -45 && rotY < 45) {
      rotacionStr = "0_degrees";
    } else if (rotY >= 45 && rotY < 135) {
      rotacionStr = "90_degrees";
    } else if (rotY >= -135 && rotY < -45) {
      rotacionStr = "270_degrees";
    } else {
      rotacionStr = "180_degrees";
    }

    const posX = centro.x - 3;
    const posY = centro.y - 3;
    const posZ = centro.z - 3;

    dimension.runCommandAsync(`structure load "${estructuraId}" ${posX} ${posY} ${posZ} ${rotacionStr}`);
  } catch (error) { }
}

// =====================================================================
// 7. MOTOR LEÑADOR ASÍNCRONO
// =====================================================================
function* motorLumberjackAsync(dimension, centro) {
  const rango = 10;
  let bloquesProcesados = 0;
  const MAX_BLOQUES_PER_TICK = 1500;

  for (let x = -rango; x <= rango; x++) {
    for (let y = -rango; y <= rango; y++) {
      for (let z = -rango; z <= rango; z++) {
        const posTarget = { x: centro.x + x, y: centro.y + y, z: centro.z + z };

        try {
          const bloque = dimension.getBlock(posTarget);
          if (bloque && bloque.isValid() && !bloque.isAir) {
            const id = bloque.typeId;

            const esArbol = id.includes("_log") ||
              id.includes("_stem") ||
              id.includes("leaves") ||
              id.includes("_wood");

            if (esArbol) {
              bloque.setType("minecraft:air");
            }
          }
        } catch (e) { }

        bloquesProcesados++;
        if (bloquesProcesados >= MAX_BLOQUES_PER_TICK) {
          bloquesProcesados = 0;
          yield;
        }
      }
    }
  }
}
