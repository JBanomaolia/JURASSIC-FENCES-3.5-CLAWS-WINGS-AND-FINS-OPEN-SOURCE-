import { world, system, EquipmentSlot, ItemStack } from "@minecraft/server";
import { ActionFormData } from "@minecraft/server-ui";
import { LogrosManager } from "./logrosManager.js";

// --- MATEMÁTICAS DE COMBUSTIBLE ---
const TICKS_POR_REDSTONE = 81600; 
const RADIO_ENERGIA = 500;
const RADIO_ENERGIA_SQ = RADIO_ENERGIA * RADIO_ENERGIA;

export const RegistrosActivos = new Map();
// 🛡️ SEGURO: Evita que el menú se abra más de una vez a la vez por jugador
const activeForms = new Set(); 

// ==========================================
// 1. REGISTRO Y GESTIÓN DE BLOQUE E ÍTEM
// ==========================================
world.beforeEvents.worldInitialize.subscribe((initEvent) => {
  // Componente para el bloque del registro eléctrico
  try {
    initEvent.blockComponentRegistry.registerCustomComponent("ap:info", {
      onPlayerInteract: (event) => {
        const { player, block } = event;
        system.run(() => interactuarRegistro(player, block));
      },
      onPlayerDestroy: (event) => {
        const { block, dimension } = event;
        romperRegistro(block, dimension);
      }
    });
  } catch (e) {
    console.warn("[JF 3.0] Error registrando bloque ap:info: " + e);
  }

  // Componente para el ítem ap:control_vallas
  try {
    initEvent.itemComponentRegistry.registerCustomComponent("ap:info", {
      onUseOn: (event) => {
        const { source: player, block } = event;
        if (player && block && block.typeId === "ap:registro_electrico") {
          system.run(() => interactuarRegistro(player, block));
        }
      }
    });
  } catch (e) {
    console.warn("[JF 3.0] Error registrando ítem ap:info: " + e);
  }
});

world.afterEvents.worldInitialize.subscribe(() => {
  try {
    const guardado = world.getDynamicProperty("registros_redstone");
    if (guardado) {
      const parsed = JSON.parse(guardado);
      for (const [key, val] of Object.entries(parsed)) {
        RegistrosActivos.set(key, val);
      }
    }
  } catch (e) {
    console.warn("[JF 3.0] Error al cargar registros de redstone: " + e);
  }
});

function guardarRegistros() {
  try {
    world.setDynamicProperty("registros_redstone", JSON.stringify(Object.fromEntries(RegistrosActivos)));
  } catch (e) {
    console.warn("[JF 3.0] Error al guardar registros de redstone: " + e);
  }
}

// ==========================================
// 2. INTERACCIÓN (REDSTONE Y CONTROL)
// ==========================================
function interactuarRegistro(player, block) {
  if (!player || !player.isValid() || !block || !block.isValid() || block.typeId !== "ap:registro_electrico") return;

  const equippable = player.getComponent("equippable");
  const mainHandItem = equippable?.getEquipment(EquipmentSlot.Mainhand);
  const locKey = `${block.location.x},${block.location.y},${block.location.z},${block.dimension.id}`;

  let reg = RegistrosActivos.get(locKey) || { ticks: 0, active: false };

  // Cargar con polvo de Redstone
  if (mainHandItem?.typeId === "minecraft:redstone") {
    const cantidad = mainHandItem.amount;
    reg.ticks += cantidad * TICKS_POR_REDSTONE;
    RegistrosActivos.set(locKey, reg);
    guardarRegistros();

    try {
      player.dimension.spawnParticle("minecraft:redstone_ore_dust_particle", {
        x: block.location.x + 0.5,
        y: block.location.y + 1.0,
        z: block.location.z + 0.5
      });
      player.playSound("random.orb", { pitch: 1.2 });
    } catch (e) { }

    player.onScreenDisplay?.setActionBar(`§a[REGISTRO] Batería cargada con +${cantidad} Redstone.`);
    
    equippable.setEquipment(EquipmentSlot.Mainhand, undefined);
    return;
  }

  // Activar con ap:control_vallas
  if (mainHandItem?.typeId === "ap:control_vallas") {
    abrirMenuRegistro(player, block, locKey, reg);
    return;
  }

  player.onScreenDisplay?.setActionBar("§eInteractúa con 'Redstone' para cargar o 'Ajustes de Vallas' para encender.");
}

function abrirMenuRegistro(player, block, locKey, reg) {
  if (activeForms.has(player.id)) return;
  activeForms.add(player.id);

  const diasRestantes = (reg.ticks / 24000).toFixed(1);
  const estadoTexto = reg.active ? "§aENCENDIDO" : "§cAPAGADO";

  const form = new ActionFormData()
    .title("§l§3REGISTRO ELÉCTRICO")
    .body(`§7Administración de perímetro (Radio: 500 bloques).\n\n§fEstado: ${estadoTexto}\n§fBatería Restante: §c${diasRestantes} días (MC)\n\n§7* 5 Redstone otorgan 17 días de energía.`)
    .button(reg.active ? "§l§4Apagar Generador" : "§l§2Encender Generador", "textures/items/control_vallas")
    .button("§l§cSalir");

  // Retraso de 10 ticks para evitar cierres accidentales en dispositivos móviles
  system.runTimeout(() => {
    if (!player || !player.isValid()) {
      activeForms.delete(player.id);
      return;
    }

    form.show(player).then((res) => {
      activeForms.delete(player.id);
      if (res.canceled || res.selection === 1) return;

      if (res.selection === 0) {
        if (!reg.active && reg.ticks <= 0) {
          try {
            player.playSound("random.break", { pitch: 0.8 });
          } catch (e) { }
          player.sendMessage("§c[SISTEMA] Combustible agotado. Introduce polvo de redstone primero.");
          return;
        }

        reg.active = !reg.active;
        RegistrosActivos.set(locKey, reg);
        guardarRegistros();

        if (reg.active) {
          try {
            if (block && block.isValid()) {
              block.dimension.spawnParticle("minecraft:electric_spark_particle", {
                x: block.location.x + 0.5, y: block.location.y + 1.0, z: block.location.z + 0.5
              });
            }
            player.playSound("random.levelup", { pitch: 1.4 });
          } catch (e) { }

          player.onScreenDisplay?.setActionBar("§a[REGISTRO] Energía FLUYENDO (500 bloques a la redonda).");
          LogrosManager.lanzar(player, "tecnologia_jurásica");
        } else {
          try {
            player.playSound("random.click", { pitch: 0.5 });
          } catch (e) { }
          player.onScreenDisplay?.setActionBar("§c[REGISTRO] Red local desconectada.");
        }
      }
    }).catch((e) => {
      activeForms.delete(player.id);
    });
  }, 10);
}

function romperRegistro(block, dimension) {
  if (!block) return;
  const locKey = `${block.location.x},${block.location.y},${block.location.z},${dimension.id}`;
  if (RegistrosActivos.has(locKey)) {
    const reg = RegistrosActivos.get(locKey);
    const redstoneADevolver = Math.floor(reg.ticks / TICKS_POR_REDSTONE);

    if (redstoneADevolver > 0) {
      let restante = redstoneADevolver;
      const spawnLocation = {
        x: block.location.x + 0.5,
        y: block.location.y + 0.5,
        z: block.location.z + 0.5
      };

      while (restante > 0) {
        let dar = Math.min(restante, 64);
        try {
          dimension.spawnItem(new ItemStack("minecraft:redstone", dar), spawnLocation);
        } catch (e) { }
        restante -= dar;
      }
    }
    RegistrosActivos.delete(locKey);
    guardarRegistros();
  }
}

// ==========================================
// 3. RELOJ DE CONSUMO (Quema energía constante)
// ==========================================
system.runInterval(() => {
  let cambio = false;
  for (const [key, reg] of RegistrosActivos.entries()) {
    if (reg.active) {
      reg.ticks -= 20;
      if (reg.ticks <= 0) {
        reg.ticks = 0;
        reg.active = false;
        cambio = true;
      }
    }
  }
  if (cambio) guardarRegistros();
}, 20);

// ==========================================
// 4. FUNCIÓN EXPORTADA (LA USA FENCES.JS)
// ==========================================
export function estaEnergizado(x, y, z, dimensionId) {
  for (const [key, reg] of RegistrosActivos.entries()) {
    if (reg.active && reg.ticks > 0) {
      const parts = key.split(",");
      if (parts.length === 4) {
        const rx = Number(parts[0]);
        const ry = Number(parts[1]);
        const rz = Number(parts[2]);
        const rdim = parts[3];

        if (rdim === dimensionId) {
          const dx = x - rx;
          const dy = y - ry;
          const dz = z - rz;
          if (dx * dx + dy * dy + dz * dz <= RADIO_ENERGIA_SQ) {
            return true; 
          }
        }
      }
    }
  }
  return false;
}
