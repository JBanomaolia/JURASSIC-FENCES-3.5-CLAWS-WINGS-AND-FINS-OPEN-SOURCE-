import { world, system, EquipmentSlot, ItemStack } from "@minecraft/server";
import { ActionFormData } from "@minecraft/server-ui";
import { LogrosManager } from "./logrosManager.js";

// ==========================================
// 🦖 BASE DE DATOS DE ESPECÍMENES
// ==========================================
const CATALOGO_DINOS = {
  tierra: [
    {
      nombre: "Albertosaurus",
      completado: true,
      variantes: [
        { nombre: "NULO", precio: 967, item: "ap:alberto_nulo_spawn_egg" },
        { nombre: "MANGARIA", precio: 1566, item: "ap:alberto_mangaria_spawn_egg" },
        { nombre: "MANGLAR", precio: 1008, item: "ap:alberto_manglar_spawn_egg" },
        { nombre: "FORESTAL", precio: 1567, item: "ap:alberto_forestal_spawn_egg" },
        { nombre: "DESERT", precio: 1300, item: "ap:alberto_desert_spawn_egg" }
      ]
    },
    {
      nombre: "Apex Rex",
      completado: true,
      variantes: [
        { nombre: "NULO", precio: 67996, item: "ap:apex_rex_spawn_egg" },
        { nombre: "PINTO", precio: 75965, item: "ap:apex_rex_pinto_spawn_egg" },
        { nombre: "CARMESÍ", precio: 89678, item: "ap:apex_rex_carmesi_spawn_egg" }
      ]
    },
    {
      nombre: "Allosaurus",
      completado: true,
      variantes: [
        { nombre: "NULO", precio: 7659, item: "ap:allo_nulo_spawn_egg" },
        { nombre: "CT", precio: 6567, item: "ap:allo_ct_spawn_egg" },
        { nombre: "COSTA", precio: 9868, item: "ap:allo_costa_spawn_egg" },
        { nombre: "DESIERTO", precio: 9346, item: "ap:allo_desert_spawn_egg" },
        { nombre: "MANGLAR", precio: 11468, item: "ap:allo_manglar_spawn_egg" },
        { nombre: "MANGARIA", precio: 5764, item: "ap:allo_mangaria_spawn_egg" },
        { nombre: "CARMESÍ", precio: 34500, item: "ap:allo_carmesi_spawn_egg" }
      ]
    },
    {
      nombre: "Apatosaurus",
      completado: true,
      variantes: [
        { nombre: "NULO", precio: 12500, item: "ap:apatosaurus_spawn_egg" }
      ]
    },
    {
      nombre: "Carnotaurus",
      completado: true,
      variantes: [
        { nombre: "NULO", precio: 1049, item: "ap:carnotaurus_spawn_egg" },
        { nombre: "COSTA", precio: 2577, item: "ap:carnotaurus_costa_spawn_egg" },
        { nombre: "MANGARIA", precio: 2003, item: "ap:carnotaurus_mangaria_spawn_egg" },
        { nombre: "MANGLAR", precio: 3456, item: "ap:carnotaurus_manglar_spawn_egg" },
        { nombre: "TIGRE", precio: 4225, item: "ap:carnotaurus_tigre_spawn_egg" },
        { nombre: "TORO", precio: 7997, item: "ap:carnotaurus_toro_spawn_egg" },
        { nombre: "CAMALEÓN", precio: 15358, item: "ap:carnotaurus_camaleon_spawn_egg" },
        { nombre: "CARMESÍ", precio: 22569, item: "ap:carnotaurus_carmesi_spawn_egg" }
      ]
    },
    {
      nombre: "Diplodocus",
      completado: true,
      variantes: [
        { nombre: "NULO", precio: 14200, item: "ap:diplodocus_spawn_egg" }
      ]
    },
    {
      nombre: "Espinosaurio",
      completado: true,
      variantes: [
        { nombre: "NULO", precio: 8289, item: "ap:espino_nulo_spawn_egg" },
        { nombre: "MANGARIA", precio: 8779, item: "ap:espino_mangaria_spawn_egg" },
        { nombre: "COSTA", precio: 8964, item: "ap:espino_costa_spawn_egg" },
        { nombre: "SHADOW", precio: 8978, item: "ap:espinosaurus_shadow_spawn_egg" },
        { nombre: "MANGLAR", precio: 8008, item: "ap:espino_manglar_spawn_egg" },
        { nombre: "CARMESÍ", precio: 22368, item: "ap:espino_carmesi_spawn_egg" }
      ]
    },
    {
      nombre: "Majungasaurus",
      completado: false,
      variantes: [{ nombre: "NULO", precio: 867 }]
    },
    {
      nombre: "Tiranosaurio rex",
      completado: true,
      variantes: [
        { nombre: "NULO", precio: 22457, item: "ap:trex_nulo_spawn_egg" },
        { nombre: "DOE", precio: 34456, item: "ap:trex_doe_spawn_egg" },
        { nombre: "REXY", precio: 35864, item: "ap:trex_rexy_spawn_egg" },
        { nombre: "BUCK", precio: 44997, item: "ap:trex_buck_spawn_egg" },
        { nombre: "BULL", precio: 44000, item: "ap:trex_bull_spawn_egg" },
        { nombre: "TIGRE", precio: 21567, item: "ap:trex_tigre_spawn_egg" },
        { nombre: "CÁÑAMO", precio: 18999, item: "ap:trex_canamo_spawn_egg" }
      ]
    },
    {
      nombre: "Theryzinosaurus",
      completado: false,
      variantes: [{ nombre: "NULO", precio: 16882 }]
    },
    {
      nombre: "Triceratops",
      completado: false,
      variantes: [{ nombre: "NULO", precio: 457 }]
    }
  ],
  cielo: [
    {
      nombre: "Pteranodon",
      completado: false,
      variantes: [{ nombre: "NULO", precio: 2774 }]
    },
    {
      nombre: "Criatura AP",
      completado: false,
      variantes: [{ nombre: "NULO", precio: 55893 }]
    }
  ],
  mar: [
    {
      nombre: "Shonisaurus",
      completado: false,
      variantes: [
        { nombre: "NULO", precio: 9846 },
        { nombre: "SEPIA", precio: 9888 },
        { nombre: "CARMESÍ", precio: 18947 }
      ]
    }
  ]
};

// ==========================================
// 🚁 BASE DE DATOS DE VEHÍCULOS
// ==========================================
const CATALOGO_VEHICULOS = {
  cielo: [
    { nombre: "Airplane JP3", precio: 11798, item: "ap:airplane_jp3_spawn_egg" },
    { nombre: "Helicóptero de Operaciones", precio: 9890, item: "ap:heli_din_spawn_egg" },
    { nombre: "Transporte Pesado (T-Rex)", precio: 10547, item: "ap:tr_din_spawn_egg" },
    { nombre: "Jaula de Contención", precio: 100, item: "ap:jaula_spawn_egg" }
  ],
  tierra: [
    { nombre: "Fertech Estándar", precio: 7854, item: "ap:fertech_spawn_egg" },
    { nombre: "Fertech Jurassic World", precio: 8131, item: "ap:fertech_jw_spawn_egg" },
    { nombre: "Fertech F&W", precio: 9845, item: "ap:fertech_fishing_and_wildlife_spawn_egg" },
    { nombre: "Fertech InGen", precio: 6468, item: "ap:fertech_din_spawn_egg" },
    { nombre: "Camión de Recursos", precio: 4672, item: "ap:camion_recursos_spawn_egg" }
  ]
};

// Helper interno para obtener el Scoreboard de Dinero
export function getDineroObjective() {
  let obj = world.scoreboard.getObjective("DINERO");
  if (!obj) {
    obj = world.scoreboard.addObjective("DINERO", "Dinero");
  }
  return obj;
}

// ==========================================
// 🛠️ REGISTRO DE COMPONENTES DEL JUEGO
// ==========================================
world.beforeEvents.worldInitialize.subscribe((init) => {
  init.itemComponentRegistry.registerCustomComponent("ap:panel_handler", {
    onUse(e) {
      system.run(() => menuPrincipal(e.source));
    },
    onUseOn(e) {
      system.run(() => menuPrincipal(e.source));
    }
  });
});

// ==========================================
// 📱 INTERFACES VISUALES
// ==========================================

function menuPrincipal(p) {
  new ActionFormData()
    .title({ translate: "ap.title.din_panelop" })
    .body({ translate: "ap.body.din_bio" })
    .button({ translate: "ap.button.din_comprar" })
    .button({ translate: "ap.button.veh_comprar" })
    .button({ translate: "ap.button.din_finanzas" })
    .show(p).then((r) => {
      if (r.canceled) return;
      if (r.selection === 0) menuCategoriasDinos(p);
      if (r.selection === 1) menuCategoriasVehiculos(p);
      if (r.selection === 2) mostrarEstadoCuenta(p);
    });
}

function mostrarEstadoCuenta(p) {
  let saldo = 0;
  try {
    saldo = getDineroObjective().getScore(p) ?? 0;
  } catch (e) { }

  new ActionFormData()
    .title({ translate: "ap.title.din_finanzas" })
    .body({ rawtext: [{ text: `\n§fTitular: §a${p.name}\n\n§fFondos Disponibles:\n§e$${saldo.toLocaleString()}\n` }] })
    .button({ translate: "ap.button.back" })
    .show(p).then(() => {
      menuPrincipal(p);
    });
}

function menuCategoriasDinos(p) {
  new ActionFormData()
    .title({ translate: "ap.title.ap_categorias" })
    .body({ translate: "ap.body.ap_categorias_bio" })
    .button({ translate: "ap.button.ap_cielo" })
    .button({ translate: "ap.button.ap_mar" })
    .button({ translate: "ap.button.ap_tierra" })
    .button({ translate: "ap.button.back" })
    .show(p).then((r) => {
      if (r.canceled || r.selection === 3) return menuPrincipal(p);
      const tipos = ["cielo", "mar", "tierra"];
      menuEspecies(p, tipos[r.selection]);
    });
}

function menuEspecies(p, cat) {
  const lista = CATALOGO_DINOS[cat];
  const form = new ActionFormData()
    .title({ rawtext: [{ translate: "ap.title.din_mercado" }, { text: ` ${cat.toUpperCase()}` }] })
    .body({ translate: "ap.body.variantes_bio" });

  lista.forEach((sp) => {
    const tagTranslate = sp.completado ? "ap.text.disponible" : "ap.text.proximamente";
    form.button({ rawtext: [{ text: `${sp.nombre}\n` }, { translate: tagTranslate }] });
  });
  form.button({ translate: "ap.button.back" });

  form.show(p).then((r) => {
    const btnVolverIndex = lista.length;
    if (r.canceled || r.selection === btnVolverIndex) return menuCategoriasDinos(p);

    const especie = lista[r.selection];

    if (!especie.completado) {
      p.sendMessage({ translate: "ap.msg.dino_nodis" });
      p.playSound("note.bass");
      return menuEspecies(p, cat);
    }

    menuVariantes(p, cat, r.selection);
  });
}

function menuVariantes(p, cat, spIndex) {
  const especie = CATALOGO_DINOS[cat][spIndex];
  const form = new ActionFormData()
    .title({ rawtext: [{ translate: "ap.title.din_variantes" }, { text: ` ${especie.nombre.toUpperCase()}` }] })
    .body({ rawtext: [{ translate: "ap.body.variantes_sel1" }, { text: ` ${especie.nombre} ` }, { translate: "ap.body.variantes_sel2" }] });

  especie.variantes.forEach((v) => {
    form.button({ rawtext: [{ text: `${v.nombre}\n§e$${v.precio.toLocaleString()}` }] });
  });
  form.button({ translate: "ap.button.back" });

  form.show(p).then((r) => {
    const btnVolverIndex = especie.variantes.length;
    if (r.canceled || r.selection === btnVolverIndex) return menuEspecies(p, cat);

    const variante = especie.variantes[r.selection];
    procesarCompra(p, variante, especie.nombre, "primer_dino");
  });
}

function menuCategoriasVehiculos(p) {
  new ActionFormData()
    .title({ translate: "ap.title.veh_categorias" })
    .body({ translate: "ap.body.veh_categorias_bio" })
    .button({ translate: "ap.button.ap_cielo" })
    .button({ translate: "ap.button.ap_tierra" })
    .button({ translate: "ap.button.back" })
    .show(p).then((r) => {
      if (r.canceled || r.selection === 2) return menuPrincipal(p);
      const tipos = ["cielo", "tierra"];
      menuListaVehiculos(p, tipos[r.selection]);
    });
}

function menuListaVehiculos(p, cat) {
  const lista = CATALOGO_VEHICULOS[cat];
  const form = new ActionFormData()
    .title({ rawtext: [{ translate: "ap.title.veh_mercado" }, { text: ` ${cat.toUpperCase()}` }] })
    .body({ translate: "ap.body.veh_bio" });

  lista.forEach((veh) => {
    form.button({ rawtext: [{ text: `${veh.nombre}\n§e$${veh.precio.toLocaleString()}` }] });
  });
  form.button({ translate: "ap.button.back" });

  form.show(p).then((r) => {
    const btnVolverIndex = lista.length;
    if (r.canceled || r.selection === btnVolverIndex) return menuCategoriasVehiculos(p);

    const vehiculo = lista[r.selection];
    procesarCompra(p, vehiculo, vehiculo.nombre, "primer_vehiculo");
  });
}

// ==========================================
// 💰 LÓGICA GENERAL DE COMPRA (API NATIVA)
// ==========================================
function procesarCompra(p, itemComprado, nombreArticulo, logro) {
  system.run(() => {
    const objDinero = getDineroObjective();
    let saldoActual = 0;
    try {
      saldoActual = objDinero.getScore(p) ?? 0;
    } catch (e) { }

    if (saldoActual < itemComprado.precio) {
      LogrosManager.lanzar(p, "error_dinero");
      return;
    }

    const container = p.getComponent("inventory")?.container;
    if (!container || container.emptySlotsCount === 0) {
      p.sendMessage({ translate: "ap.msg.ap_inv" });
      return;
    }

    // Descontar saldo con API nativa sin latencia de comandos
    objDinero.addScore(p, -itemComprado.precio);

    // Entregar ítem directamente usando la clase ItemStack
    try {
      container.addItem(new ItemStack(itemComprado.item, 1));
    } catch (e) {
      p.runCommandAsync(`give @s ${itemComprado.item} 1`).catch(() => { });
    }

    p.sendMessage({
      rawtext: [
        { translate: "ap.msg.ap_trans_a" },
        { text: ` §b${nombreArticulo}§a.` }
      ]
    });

    LogrosManager.lanzar(p, logro);
  });
}
