import { world, system } from "@minecraft/server";
import { ActionFormData, ModalFormData } from "@minecraft/server-ui";

const CRISTALES_AVIARIO = [
  { nombre: "ap.cristal.celeste", id: "minecraft:light_blue_stained_glass" },
  { nombre: "ap.cristal.aviary_glass", id: "ap:aviary_glass" },
  { nombre: "ap.cristal.transparente", id: "minecraft:glass" },
  { nombre: "ap.cristal.blanco", id: "minecraft:white_stained_glass" },
  { nombre: "ap.cristal.gris_claro", id: "minecraft:light_gray_stained_glass" },
  { nombre: "ap.cristal.gris", id: "minecraft:gray_stained_glass" },
  { nombre: "ap.cristal.negro", id: "minecraft:black_stained_glass" },
  { nombre: "ap.cristal.rojo", id: "minecraft:red_stained_glass" },
  { nombre: "ap.cristal.azul", id: "minecraft:blue_stained_glass" },
  { nombre: "ap.cristal.verde", id: "minecraft:green_stained_glass" },
  { nombre: "ap.cristal.amarillo", id: "minecraft:yellow_stained_glass" },
  { nombre: "ap.cristal.rosa", id: "minecraft:pink_stained_glass" },
  { nombre: "ap.cristal.morado", id: "minecraft:purple_stained_glass" }
];

const CONCRETOS_GEOMETRIAS = [
  { nombre: "ap.color.blanco", id: "minecraft:white_concrete" },
  { nombre: "ap.color.gris_claro", id: "minecraft:light_gray_concrete" },
  { nombre: "ap.color.gris", id: "minecraft:gray_concrete" },
  { nombre: "ap.color.negro", id: "minecraft:black_concrete" },
  { nombre: "ap.color.marron", id: "minecraft:brown_concrete" },
  { nombre: "ap.color.rojo", id: "minecraft:red_concrete" },
  { nombre: "ap.color.naranja", id: "minecraft:orange_concrete" },
  { nombre: "ap.color.amarillo", id: "minecraft:yellow_concrete" },
  { nombre: "ap.color.lima", id: "minecraft:lime_concrete" },
  { nombre: "ap.color.verde", id: "minecraft:green_concrete" },
  { nombre: "ap.color.cian", id: "minecraft:cyan_concrete" },
  { nombre: "ap.color.celeste", id: "minecraft:light_blue_concrete" },
  { nombre: "ap.color.azul", id: "minecraft:blue_concrete" },
  { nombre: "ap.color.morado", id: "minecraft:purple_concrete" },
  { nombre: "ap.color.magenta", id: "minecraft:magenta_concrete" },
  { nombre: "ap.color.rosa", id: "minecraft:pink_concrete" }
];

const MADERAS_GEOMETRIAS = [
  { nombre: "ap.wood.oak", id: "minecraft:oak_planks" },
  { nombre: "ap.wood.spruce", id: "minecraft:spruce_planks" },
  { nombre: "ap.wood.birch", id: "minecraft:birch_planks" },
  { nombre: "ap.wood.jungle", id: "minecraft:jungle_planks" },
  { nombre: "ap.wood.acacia", id: "minecraft:acacia_planks" },
  { nombre: "ap.wood.dark_oak", id: "minecraft:dark_oak_planks" },
  { nombre: "ap.wood.mangrove", id: "minecraft:mangrove_planks" },
  { nombre: "ap.wood.cherry", id: "minecraft:cherry_planks" },
  { nombre: "ap.wood.bamboo", id: "minecraft:bamboo_planks" },
  { nombre: "ap.wood.crimson", id: "minecraft:crimson_planks" },
  { nombre: "ap.wood.warped", id: "minecraft:warped_planks" }
];

const LADRILLOS_GEOMETRIAS = [
  { nombre: "ap.brick.stone", id: "minecraft:stone_bricks" },
  { nombre: "ap.brick.clay", id: "minecraft:brick_block" },
  { nombre: "ap.brick.deepslate", id: "minecraft:deepslate_bricks" },
  { nombre: "ap.brick.mud", id: "minecraft:mud_bricks" },
  { nombre: "ap.brick.nether", id: "minecraft:nether_brick" },
  { nombre: "ap.brick.quartz", id: "minecraft:quartz_bricks" },
  { nombre: "ap.brick.end", id: "minecraft:end_bricks" },
  { nombre: "ap.brick.prismarine", id: "minecraft:prismarine_bricks" }
];

const TODOS_LOS_MATERIALES = [
  ...CONCRETOS_GEOMETRIAS,
  ...CRISTALES_AVIARIO,
  ...MADERAS_GEOMETRIAS,
  ...LADRILLOS_GEOMETRIAS
];

const CATALOGO_ESTRUCTURAS = [
  { nombre: "ap.structure.centro_acu", id: "centro_acu" },
  { nombre: "ap.structure.centro_cientifico", id: "centro_cientifico" },
  { nombre: "ap.structure.estacion_electrica", id: "estacion_electrica" },
  { nombre: "ap.structure.hatchery", id: "hatchery" },
  { nombre: "ap.structure.jurassic_tour", id: "jurassic_tour" },
  { nombre: "ap.structure.mirador", id: "mirador" },
  { nombre: "ap.structure.punto_llegada", id: "punto_llegada" },
  { nombre: "ap.structure.research_center", id: "research_center" },
  { nombre: "ap.structure.ziplin_1", id: "ziplin_1" },
  { nombre: "ap.structure.ziplin_2", id: "ziplin_2" }
];

const ROTACIONES_ESTRUCTURA = [
  { translate: "ap.rotation.0", val: "0_degrees" },
  { translate: "ap.rotation.90", val: "90_degrees" },
  { translate: "ap.rotation.180", val: "180_degrees" },
  { translate: "ap.rotation.270", val: "270_degrees" }
];

// =====================================================================
// REGISTRO DE COMPONENTES DE BLOQUE
// =====================================================================
world.beforeEvents.worldInitialize.subscribe((initEvent) => {
  const funcionIndicador = (event) => {
    const { player, block } = event;
    if (!player || !block) return;
    system.run(() => abrirMenuIndicador(player, block));
  };

  initEvent.blockComponentRegistry.registerCustomComponent("ap:decoracion_indicador", { onPlayerInteract: funcionIndicador });
  initEvent.blockComponentRegistry.registerCustomComponent("ap:indicator", { onPlayerInteract: funcionIndicador });
});

// =====================================================================
// MANEJO DE PROPIEDADES DINÁMICAS (WORLD KEY)
// =====================================================================
function obtenerClaveBloque(block) {
  return `ap_cfg_${block.dimension.id}_${block.location.x}_${block.location.y}_${block.location.z}`;
}

function obtenerConfiguracionBloque(block, tipoDefault) {
  try {
    const key = obtenerClaveBloque(block);
    const data = world.getDynamicProperty(key);
    if (data) {
      const parsed = JSON.parse(data);
      if (parsed.tipo === tipoDefault) return parsed;
    }
  } catch (e) { }
  return null;
}

function guardarConfiguracionBloque(block, config) {
  try {
    const key = obtenerClaveBloque(block);
    world.setDynamicProperty(key, JSON.stringify(config));
  } catch (e) { }
}

// =====================================================================
// MENÚS DE INTERFAZ
// =====================================================================
function abrirMenuIndicador(player, block) {
  new ActionFormData()
    .title({ translate: "ap.title.menu_indicador" })
    .body({ translate: "ap.body.menu_indicador" })
    .button({ translate: "ap.button.generador_aviario" })
    .button({ translate: "ap.button.generador_geometrias" })
    .button({ translate: "ap.button.generador_estructuras" })
    .show(player).then(r => {
      if (r.canceled) return;
      if (r.selection === 0) abrirMenuAviario(player, block);
      else if (r.selection === 1) abrirMenuGeometrias(player, block);
      else if (r.selection === 2) abrirMenuEstructuras(player, block);
    }).catch(e => console.warn(e));
}

function abrirMenuAviario(player, block) {
  const configGuardada = obtenerConfiguracionBloque(block, "aviario");
  const form = new ModalFormData();
  form.title({ translate: "ap.title.aviario_menu" });

  const nombresCristales = CRISTALES_AVIARIO.map(c => ({ translate: c.nombre }));

  let defaultCristal = 0;
  let defaultRadio = 20;

  if (configGuardada) {
    const indexCristal = CRISTALES_AVIARIO.findIndex(c => c.id === configGuardada.blockTypeId);
    if (indexCristal !== -1) defaultCristal = indexCristal;
    if (configGuardada.radio) defaultRadio = configGuardada.radio;
  }

  form.dropdown({ translate: "ap.dropdown.aviario_material" }, nombresCristales, defaultCristal);
  form.slider({ translate: "ap.slider.aviario_radio" }, 10, 40, 1, defaultRadio);

  form.show(player).then((response) => {
    if (response.canceled) return;
    const [iCristal, radioElegido] = response.formValues;
    const bloqueSel = CRISTALES_AVIARIO[iCristal].id;

    guardarConfiguracionBloque(block, { tipo: "aviario", blockTypeId: bloqueSel, radio: radioElegido });

    player.sendMessage({ translate: "ap.message.construccion_inicio" });
    system.runJob(motorConstruccionAsync(block.location, radioElegido, 0, "domo", 1, false, block.dimension, bloqueSel, player));
  }).catch(e => console.warn(e));
}

function abrirMenuGeometrias(player, block) {
  const configGuardada = obtenerConfiguracionBloque(block, "geometria");
  const form = new ModalFormData();
  form.title({ translate: "ap.title.geometrias_menu" });

  const opcionesFiguras = [
    { translate: "ap.shape.cuadrado" }, { translate: "ap.shape.cubo" }, { translate: "ap.shape.rectangulo" },
    { translate: "ap.shape.prisma_rectangular" }, { translate: "ap.shape.circulo" }, { translate: "ap.shape.esfera" },
    { translate: "ap.shape.cilindro" }, { translate: "ap.shape.piramide" }, { translate: "ap.shape.cono" },
    { translate: "ap.shape.hexagono" }, { translate: "ap.shape.prisma_hexagonal" }
  ];

  const tipos = ["cuadrado", "cubo", "rectangulo", "prisma_rectangular", "circulo", "esfera", "cilindro", "piramide", "cono", "hexagono", "prisma_hexagonal"];
  const opcionesEjes = [{ translate: "ap.axis.x" }, { translate: "ap.axis.y" }, { translate: "ap.axis.z" }];
  const nombresMateriales = TODOS_LOS_MATERIALES.map(c => ({ translate: c.nombre }));

  let defFigura = 0, defMaterial = 0, defRadio = 10, defAltura = 10, defEje = 1, defRelleno = false;

  if (configGuardada) {
    const idxFig = tipos.indexOf(configGuardada.figura);
    if (idxFig !== -1) defFigura = idxFig;
    const idxMat = TODOS_LOS_MATERIALES.findIndex(m => m.id === configGuardada.blockTypeId);
    if (idxMat !== -1) defMaterial = idxMat;
    if (configGuardada.radio) defRadio = configGuardada.radio;
    if (configGuardada.altura) defAltura = configGuardada.altura;
    if (configGuardada.eje !== undefined) defEje = configGuardada.eje;
    if (configGuardada.relleno !== undefined) defRelleno = configGuardada.relleno;
  }

  form.dropdown({ translate: "ap.dropdown.geometria_tipo" }, opcionesFiguras, defFigura);
  form.dropdown({ translate: "ap.dropdown.geometria_color" }, nombresMateriales, defMaterial);
  form.slider({ translate: "ap.slider.geometria_radio" }, 5, 40, 1, defRadio);
  form.slider({ translate: "ap.slider.geometria_altura" }, 1, 64, 1, defAltura);
  form.dropdown({ translate: "ap.dropdown.geometria_direccion" }, opcionesEjes, defEje);
  form.toggle({ translate: "ap.toggle.geometria_relleno" }, defRelleno);

  form.show(player).then((response) => {
    if (response.canceled) return;
    const [iFigura, iMaterial, radioElegido, alturaElegida, iEje, rellenoElegido] = response.formValues;

    const bloqueSel = TODOS_LOS_MATERIALES[iMaterial].id;
    const figuraElegida = tipos[iFigura];

    guardarConfiguracionBloque(block, {
      tipo: "geometria",
      figura: figuraElegida,
      blockTypeId: bloqueSel,
      radio: radioElegido,
      altura: alturaElegida,
      eje: iEje,
      relleno: rellenoElegido
    });

    player.sendMessage({ translate: "ap.message.construccion_inicio" });
    system.runJob(motorConstruccionAsync(block.location, radioElegido, alturaElegida, figuraElegida, iEje, rellenoElegido, block.dimension, bloqueSel, player));
  }).catch(e => console.warn(e));
}

function abrirMenuEstructuras(player, block) {
  const configGuardada = obtenerConfiguracionBloque(block, "estructura");
  const form = new ModalFormData();
  form.title({ translate: "ap.title.estructuras_menu" });

  const nombresEstructuras = CATALOGO_ESTRUCTURAS.map(e => ({ translate: e.nombre }));
  const nombresRotaciones = ROTACIONES_ESTRUCTURA.map(r => ({ translate: r.translate }));

  let defEstr = 0, defRot = 0;
  if (configGuardada) {
    const idxEstr = CATALOGO_ESTRUCTURAS.findIndex(e => e.id === configGuardada.estructuraId);
    if (idxEstr !== -1) defEstr = idxEstr;
    const idxRot = ROTACIONES_ESTRUCTURA.findIndex(r => r.val === configGuardada.rotacion);
    if (idxRot !== -1) defRot = idxRot;
  }

  form.dropdown({ translate: "ap.dropdown.estructura_tipo" }, nombresEstructuras, defEstr);
  form.dropdown({ translate: "ap.dropdown.estructura_rotacion" }, nombresRotaciones, defRot);

  form.show(player).then((response) => {
    if (response.canceled) return;
    const [iEstructura, iRotacion] = response.formValues;
    const estructuraSeleccionada = CATALOGO_ESTRUCTURAS[iEstructura].id;
    const rotacionSeleccionada = ROTACIONES_ESTRUCTURA[iRotacion].val;

    guardarConfiguracionBloque(block, {
      tipo: "estructura",
      estructuraId: estructuraSeleccionada,
      rotacion: rotacionSeleccionada
    });

    const loc = block.location;
    player.sendMessage({ translate: "ap.message.construccion_inicio" });

    try {
      block.dimension.runCommandAsync(`structure load "${estructuraSeleccionada}" ${loc.x} ${loc.y} ${loc.z} ${rotacionSeleccionada}`);
      player.sendMessage({ translate: "ap.message.construccion_exito" });
      player.playSound("random.levelup");
    } catch (e) {
      player.sendMessage({ translate: "ap.message.error_estructura" });
    }
  }).catch(e => console.warn(e));
}

// =====================================================================
// MOTOR DE CONSTRUCCIÓN ASÍNCRONO
// =====================================================================
function* motorConstruccionAsync(centro, radio, altura, tipo, eje, relleno, dimension, blockTypeId, player) {
  const cx = centro.x;
  const cy = centro.y - 1;
  const cz = centro.z;
  let ops = 0;
  const LIMIT = 150;

  if (tipo === "domo") {
    const rSq = radio * radio;
    const rIntSq = (radio - 1) * (radio - 1);
    for (let x = -radio; x <= radio; x++) {
      for (let y = 0; y <= radio; y++) {
        for (let z = -radio; z <= radio; z++) {
          const dist = (x * x) + (y * y) + (z * z);
          if (dist <= rSq) {
            const isEdge = dist >= rIntSq;
            const worldPos = { x: cx + x, y: cy + y, z: cz + z };

            if (isEdge) {
              if (++ops > LIMIT) { yield; ops = 0; }
              aplicarBloque(dimension, worldPos, blockTypeId);
            } else if (!relleno) {
              if (++ops > LIMIT) { yield; ops = 0; }
              try {
                const b = dimension.getBlock(worldPos);
                if (b && b.typeId === blockTypeId) aplicarBloque(dimension, worldPos, "minecraft:air");
              } catch (e) { }
            }
          }
        }
      }
    }
  } else {
    const maxH = altura;
    for (let lx = -radio; lx <= radio; lx++) {
      for (let ly = 0; ly < maxH; ly++) {
        for (let lz = -radio; lz <= radio; lz++) {
          let inside = false;
          let isEdge = false;

          if (tipo === "cuadrado" || tipo === "cubo") {
            inside = true;
            isEdge = Math.abs(lx) === radio || Math.abs(lz) === radio;
            if (tipo === "cubo" && (ly === 0 || ly === maxH - 1)) isEdge = true;
          } else if (tipo === "rectangulo" || tipo === "prisma_rectangular") {
            const radZ = Math.max(1, Math.floor(radio / 2));
            if (Math.abs(lz) <= radZ) {
              inside = true;
              isEdge = Math.abs(lx) === radio || Math.abs(lz) === radZ;
              if (tipo === "prisma_rectangular" && (ly === 0 || ly === maxH - 1)) isEdge = true;
            }
          } else if (tipo === "circulo" || tipo === "cilindro") {
            const dist2D = lx * lx + lz * lz;
            const rSq = radio * radio;
            const rIntSq = (radio - 1) * (radio - 1);
            if (dist2D <= rSq) {
              inside = true;
              isEdge = dist2D >= rIntSq;
              if (tipo === "cilindro" && (ly === 0 || ly === maxH - 1)) isEdge = true;
            }
          } else if (tipo === "esfera") {
            const radY = maxH / 2;
            const cy_local = ly - radY + 0.5;
            const scaledY = radY === 0 ? 0 : cy_local * (radio / radY);
            const dist3D = lx * lx + scaledY * scaledY + lz * lz;
            const rSq = radio * radio;
            if (dist3D <= rSq) {
              inside = true;
              isEdge = dist3D >= (radio - 1) * (radio - 1);
            }
          } else if (tipo === "piramide") {
            const cr = radio - Math.round((ly / Math.max(1, maxH - 1)) * radio);
            if (cr >= 0 && Math.abs(lx) <= cr && Math.abs(lz) <= cr) {
              inside = true;
              isEdge = Math.abs(lx) === cr || Math.abs(lz) === cr || ly === 0;
            }
          } else if (tipo === "cono") {
            const cr = radio - (ly / Math.max(1, maxH - 1)) * radio;
            const dist2D = lx * lx + lz * lz;
            const crSq = cr * cr;
            const crIntSq = Math.max(0, (cr - 1)) * (cr - 1);
            if (cr >= 0 && dist2D <= crSq) {
              inside = true;
              isEdge = dist2D >= crIntSq || ly === 0;
            }
          } else if (tipo === "hexagono" || tipo === "prisma_hexagonal") {
            const distHex = Math.max(Math.abs(lx), (Math.abs(lx) + Math.abs(lz) * 1.732) / 2);
            if (distHex <= radio) {
              inside = true;
              isEdge = distHex >= radio - 1;
              if (tipo === "prisma_hexagonal" && (ly === 0 || ly === maxH - 1)) isEdge = true;
            }
          }

          if (inside) {
            let rx = lx, ry = ly, rz = lz;
            if (eje === 0) { rx = ly; ry = lx + radio; rz = lz; }
            else if (eje === 2) { rx = lx; ry = lz + radio; rz = ly; }

            const worldPos = { x: cx + rx, y: cy + ry, z: cz + rz };

            if (isEdge || relleno) {
              if (++ops > LIMIT) { yield; ops = 0; }
              aplicarBloque(dimension, worldPos, blockTypeId);
            } else {
              if (++ops > LIMIT) { yield; ops = 0; }
              try {
                const b = dimension.getBlock(worldPos);
                if (b && b.typeId === blockTypeId) aplicarBloque(dimension, worldPos, "minecraft:air");
              } catch (e) { }
            }
          }
        }
      }
    }
  }

  player.sendMessage({ translate: "ap.message.construccion_exito" });
  player.playSound("random.levelup");
}

function aplicarBloque(dimension, pos, id) {
  try {
    const b = dimension.getBlock(pos);
    if (b && b.isValid()) b.setType(id);
  } catch (e) { }
}
