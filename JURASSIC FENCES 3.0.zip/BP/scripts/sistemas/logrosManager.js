import { world, system } from "@minecraft/server";

// =================================================================
// 🌐 BASE DE DATOS MULTI-IDIOMA DE LOGROS Y TUTORIALES (ES / EN)
// =================================================================
const BASE_NOTIFICACIONES = {
  "recinto_seguro": {
    tipo: "logro",
    sonido: "random.toast",
    idiomas: {
      es: {
        titulo: "§e ¡LOGRO OBTENIDO!",
        subtitulo: "§b\"Peligro contenido, vidas a salvo\"",
        chat: "§e[LOGRO] §a%player% ha asegurado su primer perímetro de contención."
      },
      en: {
        titulo: "§e ACHIEVEMENT UNLOCKED!",
        subtitulo: "§b\"Danger contained, lives safe\"",
        chat: "§e[ACHIEVEMENT] §a%player% has secured their first containment perimeter."
      }
    }
  },
  "primer_dino": {
    tipo: "logro",
    sonido: "random.toast",
    idiomas: {
      es: {
        titulo: "§6 ACTIVO ADQUIRIDO",
        subtitulo: "§fBienvenido a la era jurásica",
        chat: "§6[INGEN] §a%player% ha clonado su primer espécimen legítimo."
      },
      en: {
        titulo: "§6 ASSET ACQUIRED",
        subtitulo: "§fWelcome to the Jurassic era",
        chat: "§6[INGEN] §a%player% has cloned their first legitimate specimen."
      }
    }
  },
  "bancarrota": {
    tipo: "logro",
    sonido: "random.toast",
    idiomas: {
      es: {
        titulo: "§cCRISIS FINANCIERA",
        subtitulo: "§7Te has quedado sin fondos de inversión",
        chat: "§c[BANCO] §7%player% ha vaciado por completo sus cuentas de InGen."
      },
      en: {
        titulo: "§cFINANCIAL CRISIS",
        subtitulo: "§7You have run out of investment funds",
        chat: "§c[BANK] §7%player% has completely emptied their InGen accounts."
      }
    }
  },
  "tuto_panel": {
    tipo: "alerta",
    sonido: "random.orb",
    idiomas: {
      es: {
        titulo: "§bTIP DE GESTIÓN",
        subtitulo: "§fUsa el panel en un bloque de registro para abrir la tienda."
      },
      en: {
        titulo: "§bMANAGEMENT TIP",
        subtitulo: "§fUse the panel on a registration block to open the shop."
      }
    }
  },
  "tuto_valla_electrica": {
    tipo: "alerta",
    sonido: "note.bassattack",
    idiomas: {
      es: {
        titulo: "§6ALTA TENSIÓN",
        subtitulo: "§7Las vallas requieren energía constante para contener dinosaurios alfa."
      },
      en: {
        titulo: "§6HIGH VOLTAGE",
        subtitulo: "§7Fences require constant power to contain alpha dinosaurs."
      }
    }
  },
  "error_dinero": {
    tipo: "alerta",
    sonido: "note.bass",
    idiomas: {
      es: {
        titulo: "§cFONDOS INSUFICIENTES",
        subtitulo: "§7Vende recursos en el bloque de registro para ganar dinero."
      },
      en: {
        titulo: "§cINSUFFICIENT FUNDS",
        subtitulo: "§7Sell resources at the registration block to earn money."
      }
    }
  },
  "alerta_escape": {
    tipo: "alerta",
    sonido: "ambient.weather.thunder",
    idiomas: {
      es: {
        titulo: "§4BRECHA DE SEGURIDAD",
        subtitulo: "§c¡Un activo biológico ha escapado de su recinto!"
      },
      en: {
        titulo: "§4SECURITY BREACH",
        subtitulo: "§cA biological asset has escaped its enclosure!"
      }
    }
  }
};

export class LogrosManager {
  static lanzar(player, idNotificacion) {
    if (!player || !player.isValid()) return;

    const data = BASE_NOTIFICACIONES[idNotificacion];

    if (!data) {
      console.warn(`[LogrosManager]: El ID de notificación '${idNotificacion}' no existe.`);
      return;
    }

    // 1. Control de logros únicos mediante propiedades dinámicas
    if (data.tipo === "logro") {
      try {
        const propiedad = `logro_${idNotificacion}`;
        if (player.getDynamicProperty(propiedad)) return;
        player.setDynamicProperty(propiedad, true);
      } catch (e) {
        console.warn(`[LogrosManager]: Error al gestionar propiedad dinámica en jugador: ${e}`);
      }
    }

    // 2. Detección segura de idioma
    let idiomaGlobal = "en_US";
    try {
      if (typeof player.getLocale === "function") {
        idiomaGlobal = player.getLocale() || "en_US";
      }
    } catch (e) { }

    const prefijoLang = idiomaGlobal.split("_")[0];
    const textos = data.idiomas[prefijoLang] || data.idiomas["en"];

    // 3. Renderizado en pantalla vía API Nativa
    system.run(() => {
      if (!player.isValid()) return;

      try {
        player.onScreenDisplay?.setTitle(textos.titulo, {
          subtitle: textos.subtitulo,
          fadeInDuration: 10,
          stayDuration: 60,
          fadeOutDuration: 10
        });
      } catch (e) { }

      try {
        if (data.sonido) {
          player.playSound(data.sonido);
        }
      } catch (e) { }

      if (textos.chat) {
        const mensajeFormateado = textos.chat.replace("%player%", player.name ?? "Jugador");
        world.sendMessage(mensajeFormateado);
      }
    });
  }
}
