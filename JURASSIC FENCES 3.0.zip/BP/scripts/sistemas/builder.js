import { world, system, BlockPermutation, GameMode } from "@minecraft/server";
import { ActionFormData, ModalFormData } from "@minecraft/server-ui";
import { LogrosManager } from "./logrosManager.js";
import { getDineroObjective } from "./operaciones.js";

// ==========================================
// 1. CONFIGURACIONES Y CATÁLOGOS
// ==========================================

const COSTO_PUERTA = 256;

export const OPCIONES_NIVELES = [
  { nombre: "Nivel 1 Lite", id: "n1_lite" },
  { nombre: "Nivel 1 Estándar", id: "n1" },
  { nombre: "Nivel 1 herbívoros", id: "n1h" },
  { nombre: "Nivel 2 Estándar", id: "n2" },
  { nombre: "Nivel 3 Estándar", id: "n3" },
  { nombre: "Nivel 3 Versión 2", id: "n3_v2" },
  { nombre: "Nivel 3 VIP", id: "n3_vip" },
  { nombre: "Nivel 4 (Seguridad Máxima)", id: "n4" },
  { nombre: "Nivel 4 (Toro)", id: "n4_toro" },
  { nombre: "Nivel 5 Estándar", id: "n5" },
  { nombre: "Nivel 5 Variante", id: "n5_v2" },
  { nombre: "Nivel 1 Rex", id: "n1_rex" },
  { nombre: "Nivel 2 Rex", id: "n2_rex" },
  { nombre: "Nivel 1 Smithy", id: "smithy0" },
  { nombre: "Nivel 2 Smithy", id: "smithy1" },
  { nombre: "Nivel 1 VIP", id: "n1_vip" },
  { nombre: "Nivel 2 VIP", id: "n2_vip" },
  { nombre: "Muro Nivel 1", id: "muro1" },
  { nombre: "Muro Nivel 2", id: "muro2" },
  { nombre: "Muro Nivel 3", id: "muro3" },
  { nombre: "Muro Nivel 4", id: "muro4" },
  { nombre: "Acuático Nivel 1", id: "acua1" },
  { nombre: "Acuático Nivel 2", id: "acua2" }
];

export const CATALOGO = {
  "n1_lite": { post: "ap:sp_n1_lite", fence: "ap:v_n1_lite", hasCorner: true, isWall: false, h: 6 },
  "n1": { post: "ap:sp_n1", fence: "ap:v_n1", hasCorner: true, isWall: false, h: 6 },
  "n1h": { post: "ap:sp_n1_h", fence: "ap:v_n1_herbivoros", hasCorner: true, isWall: false, h: 6 },
  "n2": { post: "ap:sp_n2", fence: "ap:v_n2", hasCorner: true, isWall: false, h: 6 },
  "n3": { post: ["ap:sp_n3_b", "ap:sp_n3", "ap:sp_n3", "ap:sp_n3", "ap:sp_n3_letrero", "ap:sp_n3"], fence: "ap:v_n3", hasCorner: true, isWall: false, h: 6 },
  "n3_v2": { post: "ap:sp_n3_v2", fence: "ap:v_n3_v2", hasCorner: true, isWall: false, h: 6 },
  "n3_vip": { post: "ap:sp_n3_vip", fence: "ap:v_n3_vip", hasCorner: true, isWall: false, h: 6 },
  "n4": { post: ["ap:sp_n40", "ap:sp_n41", "ap:sp_n41", "ap:sp_n41", "ap:sp_n41", "ap:sp_n42"], fence: "ap:v_n4", hasCorner: true, isWall: false, h: 6 },
  "n4_toro": { post: ["ap:sp_toro_base", "ap:sp_toro_poste", "ap:sp_toro_poste", "ap:sp_toro_poste", "ap:sp_toro_poste", "ap:sp_toro_lamp"], fence: "ap:v_toro", hasCorner: true, isWall: false, h: 6 },
  "n5": { post: "ap:sp_n5", fence: "ap:v_n5", hasCorner: true, isWall: false, h: 6 },
  "n5_v2": { post: "ap:sp_n5_v2", fence: "ap:v_n5_v2", hasCorner: true, isWall: false, h: 6 },
  "n1_rex": { post: ["ap:sp_n3_trex", "ap:sp_n3_trex", "ap:sp_n3_trex", "ap:sp_n3_trex", "ap:sp_n3_trex", "ap:sp_n3_trex_alto"], fence: "ap:v_n3_rex", hasCorner: true, isWall: false, h: 6 },
  "n2_rex": { post: ["ap:sp_n3_trex_v2", "ap:sp_n3_trex_v2", "ap:sp_n3_trex_v2", "ap:sp_n3_trex_v2", "ap:sp_n3_trex_v2", "ap:sp_n3_trex_v2_alto"], fence: "ap:v_n3_rex_v2", hasCorner: true, isWall: false, h: 6 },
  "smithy0": { post: "ap:sp_smithy0", fence: "ap:v_smithy0", hasCorner: true, isWall: false, h: 6 },
  "smithy1": { post: "ap:sp_smithy1", fence: "ap:v_smithy2", hasCorner: true, isWall: false, h: 6 },
  "n1_vip": { post: "ap:sp_n1_vip", fence: "ap:v_n1_vip", hasCorner: true, isWall: false, h: 6 },
  "n2_vip": { post: "ap:sp_n2_vip", fence: "ap:v_n2_vip", hasCorner: true, isWall: false, h: 6 },
  "muro1": { post: "ap:sp_muro_0_vip", fence: "ap:muro_0_vip", hasCorner: true, isWall: false, h: 6 },
  "muro2": { post: "ap:sp_muro_n2", fence: "ap:muro_n2", hasCorner: true, isWall: false, h: 6 },
  "muro3": { post: "ap:sp_muro_n3", fence: "ap:muro_n3", hasCorner: true, isWall: false, h: 6 },
  "muro4": { post: "ap:sp_muro_n4", fence: "ap:muro_n4", hasCorner: true, isWall: false, h: 6 },
  "acua1": { post: "ap:sp_acuatica", fence: "ap:valla_acuatica", hasCorner: true, isWall: false, h: 1 },
  "acua2": { post: "ap:sp_acuatica_v2", fence: "ap:valla_acuatica_v2", hasCorner: true, isWall: false, h: 1 }
};

export const COSTOS = {
  GRUPO: { redstone: 5, hierro: 10, dinero: 25 },
  CIRCUITO: { redstone: 50, hierro: 64, dinero: 156 }
};


// ==========================================
// 2. EVENTO CONTROL VALLAS (Uso de ítem)
// ==========================================
world.beforeEvents.itemUseOn.subscribe((e) => {
  const { source: player, itemStack: item, block } = e;
  
  if (item?.typeId === "ap:control_vallas") {
    e.cancel = true;
    const id = block.typeId;
    
    // Identificadores de lógica
    const esBase = block.hasTag("ap:base") || (id.includes("base_valla") && !id.includes("barrera"));
    const esBarrera = block.hasTag("ap:barrera") || block.hasTag("ap:builder_conductual_acuatico") || id.includes("barrera");
    
    if (esBase || esBarrera) {
      system.run(() => abrirMenuMaestroVallas(player, block, esBase, esBarrera));
    }
  }
});


// ==========================================
// 3. LÓGICA DE INTERFACES (Exportadas)
// ==========================================

export function abrirMenuMaestroVallas(player, block, esBase, esBarrera) {
  new ActionFormData()
    .title({ translate: "ap.title.vallas_menu1" })
    .body({ translate: "ap.body.vallas_menu1" })
    .button({ translate: "ap.button.vallas_menu1a" })
    .button({ translate: "ap.button.colocar_puertas" })
    .button({ translate: "ap.button.vallas_menu1b" })
    .show(player).then(r => {
      if (r.canceled) return;
      if (r.selection === 0) {
        esBase ? abrirInterfazNiveles(player, block) : abrirInterfazModoRelleno(player, block);
      } else if (r.selection === 1) {
        abrirMenuPuerta(player, block);
      } else if (r.selection === 2) {
        abrirMenuDemolicion(player, block);
      }
    });
}

export function abrirMenuPuerta(player, block) {
  new ActionFormData()
    .title({ translate: "ap.title.eleccion_puertas" })
    .body("Selecciona el tipo de puerta que deseas construir:")
    .button("Puerta Azul")
    .button("Puerta Roja")
    .button("Puerta N4")
    .show(player).then(r => {
      if (r.canceled) return;
      const estructuras = ["mystructure:p_azul", "mystructure:p_roja", "mystructure:p_n4"];
      const estructuraElegida = estructuras[r.selection];
      
      if (estructuraElegida) {
        intentarColocarPuerta(player, block, estructuraElegida);
      }
    });
}

function abrirInterfazNiveles(player, block) {
  new ModalFormData()
    .title({ translate: "ap.title.eleccion_postes" })
    .dropdown({ translate: "ap.dropdown.variante" }, OPCIONES_NIVELES.map(o => o.nombre))
    .show(player).then(r => {
      if (!r.canceled) construirColumnasEnRed(player, block, OPCIONES_NIVELES[r.formValues[0]].id);
    }).catch(() => { });
}

function abrirInterfazModoRelleno(player, block) {
  new ActionFormData()
    .title({ translate: "ap.title.vallas_relleno" })
    .button({ translate: "ap.button.vallas_grupo" })
    .button({ translate: "ap.button.vallas_circuito" })
    .show(player).then(r => {
      if (r.canceled) return;
      r.selection === 0 ? ejecutarRelleno(player, block) : ejecutarRellenoCompleto(player, block);
    });
}

function abrirMenuDemolicion(player, block) {
  new ActionFormData()
    .title({ translate: "ap.title.demolicion" })
    .button({ translate: "ap.button.vallas_demoler_grupo" })
    .show(player).then(r => {
      if (!r.canceled) ejecutarDemolicion(player, block);
    });
}


// ==========================================
// 4. SISTEMA DE PUERTAS Y COBROS
// ==========================================

async function intentarColocarPuerta(player, block, estructuraElegida) {
  const obj = world.scoreboard.getObjective("puntos");
  const pts = obj ? (obj.getScore(player) ?? 0) : 0;
  const isCreative = player.getGameMode() === GameMode.creative;

  if (!isCreative && pts < COSTO_PUERTA) {
    player.sendMessage({ translate: "ap.builder.puerta_sin_puntos" });
    player.playSound("note.bass");
    return;
  }

  const loc = block.location;
  const dimension = player.dimension;
  let rot = obtenerRotacionExacta(block);
  let rotStr = rot ? rot.val.toString().toLowerCase() : "0";

  let rotacionEstructura = "0_degrees";
  let offsetZ = 0, offsetX = 0; // Colocación en la coordenada exacta

  if (rotStr === "2" || rotStr === "north" || rotStr === "south" || rotStr === "0") {
    rotacionEstructura = (rotStr === "2" || rotStr === "north") ? "180_degrees" : "0_degrees";
  } else {
    rotacionEstructura = (rotStr === "1" || rotStr === "west") ? "270_degrees" : "90_degrees";
  }

  try {
    const comando = `structure load "${estructuraElegida}" ${loc.x + offsetX} ${loc.y} ${loc.z + offsetZ} ${rotacionEstructura}`;
    await dimension.runCommandAsync(comando);

    if (!isCreative && obj) obj.addScore(player, -COSTO_PUERTA);

    player.sendMessage({ translate: "ap.builder.puerta_exito" });
    player.playSound("random.vallas_sound"); 
    dimension.spawnParticle("minecraft:conduit_particle", {x: loc.x + 0.5, y: loc.y + 1, z: loc.z + 0.5});
  } catch (error) {
    player.sendMessage(`§cError de construcción: No se pudo cargar la estructura.`);
  }
}

function consumirItemsExactos(inv, typeId, cantidad) {
  let restantes = cantidad;
  for (let i = 0; i < inv.size && restantes > 0; i++) {
    const item = inv.getItem(i);
    if (item?.typeId === typeId) {
      if (item.amount > restantes) {
        item.amount -= restantes;
        inv.setItem(i, item);
        restantes = 0;
      } else {
        restantes -= item.amount;
        inv.setItem(i, undefined);
      }
    }
  }
}

function validarYConsumirRequisitos(player, modo) {
  if (player.getGameMode() === GameMode.creative) return true;
  const inv = player.getComponent("inventory")?.container;
  if (!inv) return false;

  const objDinero = getDineroObjective();
  const score = objDinero.getScore(player) ?? 0;
  const req = COSTOS[modo];

  let countRed = 0, countHierro = 0;
  for (let i = 0; i < inv.size; i++) {
    const item = inv.getItem(i);
    if (item?.typeId === "minecraft:redstone") countRed += item.amount;
    if (item?.typeId === "minecraft:iron_ingot") countHierro += item.amount;
  }

  if (countRed >= req.redstone && countHierro >= req.hierro && score >= req.dinero) {
    objDinero.addScore(player, -req.dinero);
    consumirItemsExactos(inv, "minecraft:redstone", req.redstone);
    consumirItemsExactos(inv, "minecraft:iron_ingot", req.hierro);
    return true;
  }

  player.sendMessage({ translate: "ap.message.sin_requisitos" });
  return false;
}


// ==========================================
// 5. LÓGICA DE CONSTRUCCIÓN ASÍNCRONA
// ==========================================

function deducirNivel(d, sL) {
  let q = [sL], v = new Set(), bL = null, it = 0;
  while (q.length > 0 && it < 3000) {
    it++;
    let l = q.shift(), k = `${l.x},${l.y},${l.z}`;
    if (v.has(k)) continue;
    v.add(k);
    let b;
    try { b = d.getBlock(l); } catch (e) { continue; }
    if (!b) continue;
    if (b.hasTag("ap:base") || (b.typeId.includes("base_valla") && !b.typeId.includes("barrera"))) { bL = l; break; }
    
    for (let dx of [1, -1, 0, 0]) for (let dz of [0, 0, 1, -1]) {
      if (dx !== 0 || dz !== 0) {
        for (let dy = -1; dy <= 1; dy++) {
          let nb;
          try { nb = d.getBlock({ x: l.x + dx, y: l.y + dy, z: l.z + dz }); } catch (e) { continue; }
          if (nb && (nb.hasTag("ap:barrera") || nb.hasTag("ap:builder_conductual_acuatico") || nb.hasTag("ap:base") || nb.typeId.includes("barrera") || nb.typeId.includes("base_valla"))) q.push(nb.location);
        }
      }
    }
  }
  
  if (!bL) return null;
  for (let h = 1; h <= 6; h++) {
    let bA;
    try { bA = d.getBlock({ x: bL.x, y: bL.y + h, z: bL.z }); } catch (e) { }
    if (bA && bA.typeId !== "minecraft:air") {
      for (let [k, val] of Object.entries(CATALOGO)) {
        let eP = Array.isArray(val.post) ? val.post[h - 1] : val.post;
        if (!eP) continue;
        if (bA.typeId === (typeof eP === "string" ? eP : eP.id)) return k;
      }
    }
  }
  return null;
}

function mapearGrupos(d, sB) {
  let visitados = new Set(), q = [sB.location], barreras = [], iters = 0;
  while (q.length > 0 && iters < 6000) {
    iters++;
    let l = q.shift(), k = `${l.x},${l.y},${l.z}`;
    if (visitados.has(k)) continue;
    visitados.add(k);
    let b;
    try { b = d.getBlock(l); } catch (e) { continue; }
    if (!b) continue;
    
    let isBase = b.hasTag("ap:base") || (b.typeId.includes("base_valla") && !b.typeId.includes("barrera"));
    let isBarrera = b.hasTag("ap:barrera") || b.hasTag("ap:builder_conductual_acuatico") || b.typeId.includes("barrera");
    
    if (isBase || isBarrera) {
      if (isBarrera) barreras.push({ x: l.x, y: l.y, z: l.z, b: b });
      for (let dx of [1, -1, 0, 0]) for (let dz of [0, 0, 1, -1]) {
        if (dx !== 0 || dz !== 0) {
          for (let dy = -2; dy <= 2; dy++) {
            let nx = l.x + dx, ny = l.y + dy, nz = l.z + dz, nk = `${nx},${ny},${nz}`;
            if (!visitados.has(nk)) q.push({ x: nx, y: ny, z: nz });
          }
        }
      }
    }
  }

  let grupos = [], barrerasVisitadas = new Set();
  for (let barr of barreras) {
    let bk = `${barr.x},${barr.y},${barr.z}`;
    if (barrerasVisitadas.has(bk)) continue;
    
    let grupoActual = [], qG = [barr], gIters = 0;
    while (qG.length > 0 && gIters < 2000) {
      gIters++;
      let curr = qG.shift(), ck = `${curr.x},${curr.y},${curr.z}`;
      if (barrerasVisitadas.has(ck)) continue;
      barrerasVisitadas.add(ck);
      grupoActual.push(curr);
      
      for (let dx of [1, -1, 0, 0]) for (let dz of [0, 0, 1, -1]) {
        if (dx !== 0 || dz !== 0) {
          for (let dy = -2; dy <= 2; dy++) {
            let nx = curr.x + dx, ny = curr.y + dy, nz = curr.z + dz, nk = `${nx},${ny},${nz}`;
            if (!barrerasVisitadas.has(nk)) {
              let nb = barreras.find(v => v.x === nx && v.y === ny && v.z === nz);
              if (nb) qG.push(nb);
            }
          }
        }
      }
    }
    if (grupoActual.length > 0) grupos.push(grupoActual);
  }
  
  grupos.sort((gA, gB) => {
    let distA = Math.min(...gA.map(v => Math.abs(v.x - sB.location.x) + Math.abs(v.y - sB.location.y) + Math.abs(v.z - sB.location.z)));
    let distB = Math.min(...gB.map(v => Math.abs(v.x - sB.location.x) + Math.abs(v.y - sB.location.y) + Math.abs(v.z - sB.location.z)));
    return distA - distB;
  });
  return grupos;
}

function* construirGrupoAsync(d, g, c) {
  let batchCount = 0;

  for (let data of g) {
    if (!data || !data.b) continue;
    let id = data.b.typeId;
    data.eE = id.includes("esquina");
    data.rO = obtenerRotacionExacta(data.b);
    data.eD = 0;
    data.iS = false;

    for (let dx of [1, -1, 0, 0]) for (let dz of [0, 0, 1, -1]) {
      if (dx !== 0 || dz !== 0) {
        for (let dy = -3; dy < 0; dy++) {
          let nb;
          try { nb = d.getBlock({ x: data.x + dx, y: data.y + dy, z: data.z + dz }); } catch (e) { continue; }
          if (nb && (nb.hasTag("ap:barrera") || nb.hasTag("ap:builder_conductual_acuatico") || nb.hasTag("ap:base") || nb.typeId.includes("base_valla") || nb.typeId.includes("barrera"))) {
            data.iS = true;
            data.eD = Math.max(data.eD, Math.abs(dy));
            break;
          }
        }
      }
    }
  }

  for (let data of g) {
    if (!data || !data.b) continue;

    if (data.iS) {
      colocarBloqueFijo(d, data.x, data.y, data.z, { id: resolveBlockData(c.post, 0).id.replace("sp_", "sp_base_").replace("acuatica", "acuatica_base"), states: {} }, data.rO);
      construirElemento(d, data.x, data.y, data.z, c.post, c.h, data.rO, data.eD, false, false, c.isWall, false);
    } else if (data.eE && !c.hasCorner && !c.isWall) {
      colocarBloqueFijo(d, data.x, data.y, data.z, { id: resolveBlockData(c.post, 0).id.replace("sp_", "sp_base_").replace("acuatica", "acuatica_base"), states: {} }, data.rO);
      construirElemento(d, data.x, data.y, data.z, c.post, c.h, data.rO, 0, false, false, false, false);
    } else {
      let adyacenteAPoste = false;
      for (let pc of g) {
        if (pc.iS && (Math.abs(pc.x - data.x) + Math.abs(pc.z - data.z) === 1)) {
          adyacenteAPoste = true;
          break;
        }
      }
      construirElemento(d, data.x, data.y, data.z, c.fence, c.h, data.rO, 0, data.eE, c.hasCorner, c.isWall, adyacenteAPoste);
    }

    batchCount++;
    if (batchCount % 3 === 0) {
      d.spawnParticle("minecraft:conduit_particle", {x: data.x + 0.5, y: data.y + 1.5, z: data.z + 0.5});
    }
    if (batchCount % 12 === 0) yield; 
  }
}

function ejecutarRellenoCompleto(player, block) {
  let d = block.dimension;
  let n = deducirNivel(d, block.location);
  if (!n) return player.sendMessage({ translate: "ap.message.error_columna" });
  let g = mapearGrupos(d, block);
  if (g.length === 0) return player.sendMessage({ translate: "ap.message.error_circuito" });
  if (!validarYConsumirRequisitos(player, "CIRCUITO")) return;

  system.runJob(function* () {
    for (let gr of g) {
      yield* construirGrupoAsync(d, gr, CATALOGO[n]);
    }
    player.sendMessage({ translate: "ap.message.exito_circuito" });
    player.playSound("random.vallas_sound");
    LogrosManager.lanzar(player, "recinto_seguro");
  }());
}

function ejecutarRelleno(player, block) {
  let d = block.dimension;
  let n = deducirNivel(d, block.location);
  if (!n) return player.sendMessage({ translate: "ap.message.error_columna" });
  let g = mapearGrupos(d, block);
  
  if (g.length > 0) {
    if (!validarYConsumirRequisitos(player, "GRUPO")) return;
    system.runJob(function* () {
      yield* construirGrupoAsync(d, g[0], CATALOGO[n]);
      player.playSound("random.vallas_sound");
      player.sendMessage({ translate: "ap.message.exito_grupo" });
    }());
  } else {
    player.sendMessage({ translate: "ap.message.error_grupo" });
  }
}

function construirColumnasEnRed(player, block, idNivel) {
  const d = block.dimension;
  const v = new Set(), q = [block.location], bases = [];
  const aire = BlockPermutation.resolve("minecraft:air");

  let it = 0;
  while (q.length > 0 && it < 3000) {
    it++;
    let l = q.shift(), k = `${l.x},${l.y},${l.z}`;
    if (v.has(k)) continue;
    v.add(k);
    let b;
    try { b = d.getBlock(l); } catch (e) { continue; }
    if (!b || !b.isValid()) continue;
    
    if (b.hasTag("ap:base") || (b.typeId.includes("base_valla") && !b.typeId.includes("barrera"))) {
      bases.push({ x: l.x, y: l.y, z: l.z, rO: obtenerRotacionExacta(b) });
    }
    
    for (let dx of [1, -1, 0, 0]) for (let dz of [0, 0, 1, -1]) {
      if (dx !== 0 || dz !== 0) {
        for (let dy = -3; dy <= 3; dy++) {
          let nb;
          try { nb = d.getBlock({ x: l.x + dx, y: l.y + dy, z: l.z + dz }); } catch (e) { continue; }
          if (nb && (nb.hasTag("ap:barrera") || nb.hasTag("ap:builder_conductual_acuatico") || nb.hasTag("ap:base") || nb.typeId.includes("base_valla") || nb.typeId.includes("barrera"))) {
            q.push(nb.location);
            break;
          }
        }
      }
    }
  }

  let configCatalogo = CATALOGO[idNivel];
  system.runJob(function* () {
    let batch = 0;
    for (let bs of bases) {
      for (let h = 1; h <= 8; h++) {
        try { d.getBlock({ x: bs.x, y: bs.y + h, z: bs.z })?.setPermutation(aire); } catch (e) { }
      }
      for (let h = 1; h <= configCatalogo.h; h++) {
        colocarBloqueFijo(d, bs.x, bs.y + h, bs.z, resolveBlockData(configCatalogo.post, h - 1), bs.rO);
      }
      batch++;
      d.spawnParticle("minecraft:conduit_particle", {x: bs.x + 0.5, y: bs.y + 1, z: bs.z + 0.5});
      if (batch % 10 === 0) yield;
    }
    player.playSound("random.vallas_sound");
  }());
}

function ejecutarDemolicion(player, block) {
  let d = block.dimension;
  let g = mapearGrupos(d, block);
  if (g.length > 0) {
    system.runJob(function* () {
      yield* borrarColumnasAsync(d, g[0], false);
      player.sendMessage({ translate: "ap.message.demolicion_exito" });
      player.playSound("random.explode");
    }());
  }
}

function* borrarColumnasAsync(d, aL, borrarBase) {
  let batch = 0;
  const aire = BlockPermutation.resolve("minecraft:air");

  for (let l of aL) {
    if (!l) continue;
    for (let h = 1; h <= 8; h++) {
      try { d.getBlock({ x: l.x, y: l.y + h, z: l.z })?.setPermutation(aire); } catch (e) { }
    }
    for (let z = 1; z <= 4; z++) {
      let bA;
      try { bA = d.getBlock({ x: l.x, y: l.y - z, z: l.z }); } catch (e) { }
      if (bA && !bA.typeId.includes("grass") && !bA.typeId.includes("dirt") && !bA.typeId.includes("stone")) {
        bA.setPermutation(aire);
      }
    }
    if (borrarBase) {
      try { d.getBlock({ x: l.x, y: l.y, z: l.z })?.setPermutation(aire); } catch (e) { }
    }
    batch++;
    if (batch % 5 === 0) d.spawnParticle("minecraft:conduit_particle", {x: l.x+0.5, y: l.y+1, z: l.z+0.5});
    if (batch % 15 === 0) yield;
  }
}

function resolveBlockData(cI, hI) {
  let dt = Array.isArray(cI) ? cI[hI] : cI;
  if (!dt) return null;
  return { id: typeof dt === "string" ? dt : dt.id, states: typeof dt === "string" ? {} : (dt.states || {}) };
}

function construirElemento(d, x, y, z, cI, h, rO, eD, isCorner, hasCorner, isWall, isAdyacentePoste) {
  for (let zD = 1; zD <= eD; zD++) colocarBloqueFijo(d, x, y - zD, z, resolveBlockData(cI, 0), rO);
  
  for (let yH = 1; yH <= h; yH++) {
    let bD = resolveBlockData(cI, yH - 1);

    if (cI === "ap:muro_n2" && isAdyacentePoste) {
      bD.id = "ap:muro_n2_conducto";
    }

    if (isCorner && isWall) {
      colocarBloqueFijo(d, x, y + yH, z, { id: "minecraft:polished_deepslate_wall", states: {} }, rO);
    } else {
      if (isCorner && hasCorner) {
        if (bD.id.includes("acuatica") || bD.id.includes("acuatico")) {
          bD.id += (yH % 2 !== 0) ? "_esquina_right" : "_esquina_left";
        } else {
          bD.id += "_esquina";
        }
      }
      colocarBloqueFijo(d, x, y + yH, z, bD, rO);
    }
  }
}

function obtenerRotacionExacta(b) {
  try {
    let s = b.permutation.getAllStates();
    if (s["minecraft:cardinal_direction"] !== undefined) return { name: "minecraft:cardinal_direction", val: s["minecraft:cardinal_direction"] };
    if (s["minecraft:facing_direction"] !== undefined) return { name: "minecraft:facing_direction", val: s["minecraft:facing_direction"] };
    if (s["ap:rotacion"] !== undefined) return { name: "ap:rotacion", val: s["ap:rotacion"] };
  } catch (e) { }
  return null;
}

function colocarBloqueFijo(d, x, y, z, bD, rO) {
  if (!bD || !bD.id) return;
  try {
    let b = d.getBlock({ x, y, z });
    if (!b) return;
    let p = (bD.states && Object.keys(bD.states).length > 0) ? BlockPermutation.resolve(bD.id, bD.states) : BlockPermutation.resolve(bD.id);
    if (rO) {
      try { p = p.withState(rO.name, rO.val); } catch (e) {
        try { p = p.withState("minecraft:cardinal_direction", rO.val); } catch (e2) { }
      }
    }
    b.setPermutation(p);
  } catch (e) { }
}
