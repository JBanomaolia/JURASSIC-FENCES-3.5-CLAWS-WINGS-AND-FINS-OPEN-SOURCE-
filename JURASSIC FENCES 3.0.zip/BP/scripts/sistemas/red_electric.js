import { world, system, EntityDamageCause } from "@minecraft/server";

// Cache de ubicaciones de bases activas en memoria: "x,y,z,dimensionId"
const basesRegistradas = new Set();

// Mapa global de vallas electrificadas (clave -> {x, y, z, dimId, nivel})
export const vallasElectrificadas = new Map();

const ALCANCE_MAXIMO_VALLAS = 32; 
const FRECUENCIA_TICK = 4;        

// --- REGISTRO EVENTUAL DE BASES USANDO EL CATÁLOGO ---
world.afterEvents.playerPlaceBlock.subscribe((event) => {
  const { block } = event;
  if (block.hasTag("ap:base") || block.typeId.startsWith("ap:base_")) {
    const clave = `${block.location.x},${block.location.y},${block.location.z},${block.dimension.id}`;
    basesRegistradas.add(clave);
  }
});

world.afterEvents.playerBreakBlock.subscribe((event) => {
  const { block, dimension } = event;
  if (block.hasTag("ap:base") || block.typeId.startsWith("ap:base_")) {
    const clave = `${block.location.x},${block.location.y},${block.location.z},${dimension.id}`;
    basesRegistradas.delete(clave);
  }
});

// --- BUCLE PRINCIPAL DE EVALUACIÓN ---
system.runInterval(() => {
  vallasElectrificadas.clear();

  for (const claveBase of basesRegistradas) {
    const [xStr, yStr, zStr, dimId] = claveBase.split(",");
    const dimension = world.getDimension(dimId);
    if (!dimension) continue;

    const posBase = { x: parseInt(xStr), y: parseInt(yStr), z: parseInt(zStr) };

    try {
      const baseBlock = dimension.getBlock(posBase);

      if (!baseBlock || (!baseBlock.hasTag("ap:base") && !baseBlock.typeId.startsWith("ap:base_"))) {
        basesRegistradas.delete(claveBase);
        continue;
      }

      if (baseBlock.getRedstonePower() === 0) continue;
      evaluarSoportesYPropagar(dimension, posBase);
    } catch (e) {}
  }

  procesarEfectosYDano();
}, FRECUENCIA_TICK);

// --- DETECCIÓN DE SOPORTES (ap:sp_n%) ---
function evaluarSoportesYPropagar(dimension, posBase) {
  let y = posBase.y + 1;

  while (y <= posBase.y + 10) {
    const posSoporte = { x: posBase.x, y: y, z: posBase.z };
    const bloqueSoporte = dimension.getBlock(posSoporte);

    if (!bloqueSoporte || (!bloqueSoporte.hasTag("ap:poste") && !bloqueSoporte.typeId.startsWith("ap:sp_"))) break;

    propagarBFS(dimension, posSoporte);
    y++;
  }
}

// --- ALGORITMO BFS (VALLAS Y BARRERAS USANDO TAGS/PREFIJOS) ---
function propagarBFS(dimension, posInicio) {
  const cola = [];
  const visitadosEnBusqueda = new Set();

  const direcciones = [
    { x: 1, y: 0, z: 0 }, { x: -1, y: 0, z: 0 },
    { x: 0, y: 0, z: 1 }, { x: 0, y: 0, z: -1 }
  ];

  for (const dir of direcciones) {
    cola.push({ pos: { x: posInicio.x + dir.x, y: posInicio.y, z: posInicio.z + dir.z }, dist: 1 });
  }

  while (cola.length > 0) {
    const { pos, dist } = cola.shift();

    if (dist > ALCANCE_MAXIMO_VALLAS) continue;

    const clavePos = `${pos.x},${pos.y},${pos.z},${dimension.id}`;
    if (visitadosEnBusqueda.has(clavePos)) continue;
    visitadosEnBusqueda.add(clavePos);

    try {
      const bBlock = dimension.getBlock(pos);
      if (!bBlock) continue;

      const typeId = bBlock.typeId;
      const esValla = bBlock.hasTag("ap:fence") || typeId.startsWith("ap:v_");
      const esBarrera = bBlock.hasTag("ap:barrera") || typeId.startsWith("ap:barrera_");

      if (esValla || esBarrera) {
        if (esValla) {
          // Extraer nivel de seguridad de manera flexible (soporta smithy, toro, n1, n2, n3, etc.)
          let nivel = 1;
          const matchNum = typeId.match(/_n(\d)/);
          if (matchNum) {
            nivel = parseInt(matchNum[1]);
          } else if (typeId.includes("toro") || typeId.includes("smithy1")) {
            nivel = 3;
          } else if (typeId.includes("dorada") || typeId.includes("smithy0")) {
            nivel = 5;
          }

          vallasElectrificadas.set(clavePos, { x: pos.x, y: pos.y, z: pos.z, dimId: dimension.id, nivel });
        }

        for (const dir of direcciones) {
          const sigPos = { x: pos.x + dir.x, y: pos.y + dir.y, z: pos.z + dir.z };
          const sigClave = `${sigPos.x},${sigPos.y},${sigPos.z},${dimension.id}`;
          if (!visitadosEnBusqueda.has(sigClave)) {
            cola.push({ pos: sigPos, dist: dist + 1 });
          }
        }
      }
    } catch (e) {}
  }
}

// --- APLICACIÓN DINÁMICA DE EFECTOS Y DAÑO ---
function procesarEfectosYDano() {
  for (const data of vallasElectrificadas.values()) {
    const dimension = world.getDimension(data.dimId);
    if (!dimension) continue;

    const centroValla = { x: data.x + 0.5, y: data.y + 0.5, z: data.z + 0.5 };
    const nivel = data.nivel;

    if (Math.random() < (0.1 + (nivel * 0.05))) {
      dimension.spawnParticle("minecraft:conduit_particle", centroValla);
    }

    if (Math.random() < 0.20) {
      dimension.playSound("spark.spark", centroValla, { volume: 0.2 + (nivel * 0.1), pitch: 1.2 });
    }

    const dañoPorNivel = {
      1: 2,   
      2: 5,   
      3: 10,  
      4: 16,  
      5: 24   
    };
    
    const dañoAplicar = dañoPorNivel[nivel] || 4;

    const entidades = dimension.getEntities({ location: centroValla, maxDistance: 1.2 });
    for (const entity of entidades) {
      entity.applyDamage(dañoAplicar, { cause: EntityDamageCause.lightning });
      dimension.playSound("ambient.weather.lightning.impact", entity.location, { volume: 0.8, pitch: 1.5 });
    }
  }
}
