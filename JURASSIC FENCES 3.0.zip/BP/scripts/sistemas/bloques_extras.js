import { world } from "@minecraft/server";

world.beforeEvents.worldInitialize.subscribe((initEvent) => {
  // Función auxiliar para registrar componentes pasivos sin riesgo de error al interactuar
  const registrarComponentePasivo = (nombreComponente) => {
    try {
      initEvent.blockComponentRegistry.registerCustomComponent(nombreComponente, {
        onPlayerInteract: () => {},
        onPlace: () => {},
        onStepOn: () => {},
        onStepOff: () => {}
      });
    } catch (e) {
      console.warn(`[JF 3.0] Error al registrar componente pasivo '${nombreComponente}': ${e}`);
    }
  };

  // Registro de bloques pasivos
  registrarComponentePasivo("ap:conector_bases");
  registrarComponentePasivo("ap:selector_estado");
});
