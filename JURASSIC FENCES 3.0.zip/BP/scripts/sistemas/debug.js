import { world, system } from "@minecraft/server";

// Memoria para guardar el índice de la propiedad seleccionada por jugador
const propiedadesSeleccionadas = new Map();

// Limpieza de memoria al salir un jugador
world.afterEvents.playerLeave.subscribe((event) => {
  propiedadesSeleccionadas.delete(event.playerId);
});

world.beforeEvents.itemUseOn.subscribe((event) => {
  const { source: player, itemStack, block } = event;

  if (!player || !player.isValid() || itemStack?.typeId !== "ap:ajustador") return;

  // Cancelar la acción predeterminada del ítem en bloques
  event.cancel = true;

  system.run(() => {
    if (!block || !block.isValid()) return;

    const perm = block.permutation;
    const states = perm.getAllStates();
    const stateNames = Object.keys(states);

    if (stateNames.length === 0) {
      player.onScreenDisplay?.setActionBar("§c[Debug]: §fEste bloque no posee estados (states) modificables.");
      player.playSound("note.bass");
      return;
    }

    // 1. SELECCIÓN DE PROPIEDAD (AGACHADO)
    if (player.isSneaking) {
      let indiceActual = propiedadesSeleccionadas.get(player.id) ?? 0;
      indiceActual = (indiceActual + 1) % stateNames.length;

      propiedadesSeleccionadas.set(player.id, indiceActual);
      const nuevaPropiedad = stateNames[indiceActual];

      player.onScreenDisplay?.setActionBar(`§e[Debug Selector]: §fPropiedad: §b${nuevaPropiedad} §7(Valor: ${states[nuevaPropiedad]})`);
      player.playSound("random.pop");
      return;
    }

    // 2. CAMBIO DE VALOR (DE PIE)
    let indice = propiedadesSeleccionadas.get(player.id) ?? 0;

    if (indice >= stateNames.length) {
      indice = 0;
      propiedadesSeleccionadas.set(player.id, 0);
    }

    const stateName = stateNames[indice];
    const currentValue = states[stateName];

    const nuevaPerm = obtenerSiguientePermutacion(perm, stateName, currentValue);

    if (nuevaPerm) {
      try {
        block.setPermutation(nuevaPerm);
        const newValue = nuevaPerm.getState(stateName);
        player.onScreenDisplay?.setActionBar(`§a[Debug Update]: §f${stateName} §e-> §b${newValue}`);
        player.playSound("place.copper");
      } catch (e) {
        player.onScreenDisplay?.setActionBar(`§c[Debug Error]: §fEstado §b${stateName} §cprotegido o inválido.`);
        player.playSound("note.bass");
      }
    } else {
      player.onScreenDisplay?.setActionBar(`§c[Debug Error]: §fNo se pudo alternar el valor de §b${stateName}`);
      player.playSound("note.bass");
    }
  });
});

function obtenerSiguientePermutacion(perm, stateName, currentValue) {
  try {
    // 1. Estados Booleanos
    if (typeof currentValue === "boolean") {
      return perm.withState(stateName, !currentValue);
    }

    // 2. Estados Numéricos
    if (typeof currentValue === "number") {
      try {
        return perm.withState(stateName, currentValue + 1);
      } catch (e) {
        // Intentar reiniciar rango
        try {
          return perm.withState(stateName, 0);
        } catch (e2) {
          return perm.withState(stateName, 1);
        }
      }
    }

    // 3. Estados de Texto / Direcciones
    if (typeof currentValue === "string") {
      const rotaciones = ["north", "east", "south", "west", "up", "down"];
      if (rotaciones.includes(currentValue)) {
        const actualIdx = rotaciones.indexOf(currentValue);
        for (let i = 1; i <= rotaciones.length; i++) {
          try {
            const nextVal = rotaciones[(actualIdx + i) % rotaciones.length];
            return perm.withState(stateName, nextVal);
          } catch (err) { }
        }
      }
    }
  } catch (err) { }

  return null;
}
