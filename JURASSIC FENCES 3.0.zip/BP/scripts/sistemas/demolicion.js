import { world, system, BlockPermutation } from "@minecraft/server";
import { ActionFormData } from "@minecraft/server-ui";

const puntosDemo = new Map();

// Limpieza al desconectarse el jugador
world.afterEvents.playerLeave.subscribe((event) => {
  puntosDemo.delete(event.playerId);
});

world.beforeEvents.itemUseOn.subscribe((event) => {
  const { source: player, itemStack, block } = event;

  if (itemStack?.typeId === "ap:delete") {
    event.cancel = true;

    const isSneaking = player.isSneaking;
    const pos = block.location;

    system.run(() => {
      if (isSneaking) {
        // PUNTO A (Agachado)
        puntosDemo.set(player.id, { a: pos });
        player.sendMessage(`§4[Punto A]:§f Marcado en X:${pos.x}, Y:${pos.y}, Z:${pos.z}`);
        player.playSound("note.pling");
      } else {
        // PUNTO B (De pie)
        const seleccion = puntosDemo.get(player.id);

        if (!seleccion || !seleccion.a) {
          player.sendMessage("§c[Error]: Agáchate para marcar el Punto A primero.");
          return;
        }

        const posA = seleccion.a;
        const posB = pos;

        const dx = Math.abs(posA.x - posB.x);
        const dy = Math.abs(posA.y - posB.y);
        const dz = Math.abs(posA.z - posB.z);

        if (dx > 50 || dy > 50 || dz > 50) {
          player.sendMessage("§c[Error]: Área demasiado grande (Máximo 50x50x50).");
          return;
        }

        seleccion.b = posB;
        abrirMenuDemolicion(player, posA, posB);
      }
    });
  }
});

function abrirMenuDemolicion(player, a, b) {
  new ActionFormData()
    .title({ translate: "gui.ap:demoledor.name" })
    .button({ translate: "button.ap:confirmar_demo.name" })
    .button({ translate: "button.ap:cancelar_demo.name" })
    .show(player)
    .then((res) => {
      if (res.canceled || res.selection === 1) {
        puntosDemo.delete(player.id);
        player.sendMessage("§e[Demolición]:§f Selección cancelada.");
        return;
      }

      if (res.selection === 0) {
        player.sendMessage("§e[Demolición]:§f Iniciando limpieza por capas...");
        system.runJob(motorDemolicionAsync(player, player.dimension, a, b));
      }
    })
    .catch((err) => console.warn(err));
}

// --- GENERADOR ASÍNCRONO DE DEMOLICIÓN INCLUSIVA ---

function* motorDemolicionAsync(player, dimension, a, b) {
  // Coordenadas absolutas de esquina a esquina (incluyendo A y B)
  const min = {
    x: Math.min(a.x, b.x),
    y: Math.min(a.y, b.y),
    z: Math.min(a.z, b.z)
  };
  const max = {
    x: Math.max(a.x, b.x),
    y: Math.max(a.y, b.y),
    z: Math.max(a.z, b.z)
  };

  let errores = 0;
  const aire = BlockPermutation.resolve("minecraft:air");

  for (let y = min.y; y <= max.y; y++) {
    // Definimos el volumen delimitado por la capa actual
    const volumenCapa = {
      min: { x: min.x, y: y, z: min.z },
      max: { x: max.x, y: y, z: max.z }
    };

    try {
      dimension.fillBlocks(volumenCapa, aire);
    } catch (e) {
      errores++;
    }

    yield; // Pausa 1 tick por capa para optimizar memoria en móvil
  }

  if (errores > 0) {
    player.sendMessage("§e[Demolición]:§f Área limpiada. Algunas capas no estaban cargadas en la simulación.");
  } else {
    player.sendMessage("§4[Demolición]:§f Área eliminada con éxito.");
    player.playSound("random.explode");
  }

  puntosDemo.delete(player.id);
}
