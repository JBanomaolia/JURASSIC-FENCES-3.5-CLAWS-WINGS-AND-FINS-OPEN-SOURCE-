import { world, system, ItemStack } from "@minecraft/server";
import { ActionFormData, ModalFormData } from "@minecraft/server-ui";
import { getDineroObjective } from "./operaciones.js";

// ==========================================
// 🛒 CATÁLOGOS DE COMPRA (ORGANIZADOS POR CATEGORÍA)
// ==========================================

// 1. Minerales (Excepción: Netherite)
const CATALOGO_MINERALES = [
  { nombre: "Carbón", id: "minecraft:coal", precio: 6 },
  { nombre: "Cobre", id: "minecraft:copper_ingot", precio: 8 },
  { nombre: "Hierro", id: "minecraft:iron_ingot", precio: 11 },
  { nombre: "Redstone", id: "minecraft:redstone", precio: 9 },
  { nombre: "Lapis Lázuli", id: "minecraft:lapis_lazuli", precio: 15 },
  { nombre: "Oro", id: "minecraft:gold_ingot", precio: 35 },
  { nombre: "Diamante", id: "minecraft:diamond", precio: 12000 },
  { nombre: "Esmeralda", id: "minecraft:emerald", precio: 15000 }
];

// 2. Alimentos y Comida (Sin carnes crudas)
const CATALOGO_COMIDA = [
  { nombre: "Pan", id: "minecraft:bread", precio: 60 },
  { nombre: "Manzana", id: "minecraft:apple", precio: 30 },
  { nombre: "Zanahoria", id: "minecraft:carrot", precio: 25 },
  { nombre: "Patata Asada", id: "minecraft:baked_potato", precio: 35 },
  { nombre: "Bacalao Cocinado", id: "minecraft:cooked_cod", precio: 35 },
  { nombre: "Salmón Cocinado", id: "minecraft:cooked_salmon", precio: 40 },
  { nombre: "Pollo Cocinado", id: "minecraft:cooked_chicken", precio: 40 },
  { nombre: "Filete Cocinado", id: "minecraft:cooked_beef", precio: 50 },
  { nombre: "Chuleta Cocinada", id: "minecraft:cooked_porkchop", precio: 50 },
  { nombre: "Tarta", id: "minecraft:cake", precio: 150 },
  { nombre: "Manzana Dorada", id: "minecraft:golden_apple", precio: 3000 },
  { nombre: "Manzana Dorada Encantada", id: "minecraft:enchanted_golden_apple", precio: 20000 }
];

// 3. Vallas y Estructuras de Contención (Niveles 1 al 4)
const CATALOGO_VALLAS = [
  // Nivel 1
  { nombre: "Base N1", id: "ap:base_n1", precio: 25 },
  { nombre: "Barrera N1", id: "ap:barrera_n1", precio: 12 },
  { nombre: "Esquina N1", id: "ap:barrera_n1_esquina", precio: 1 },
  // Nivel 2
  { nombre: "Base N2", id: "ap:base_n2", precio: 50 },
  { nombre: "Barrera N2", id: "ap:barrera_n2", precio: 25 },
  { nombre: "Esquina N2", id: "ap:barrera_n2_esquina", precio: 3 },
  // Nivel 3
  { nombre: "Base N3", id: "ap:base_n3", precio: 100 },
  { nombre: "Barrera N3", id: "ap:barrera_n3", precio: 50 },
  { nombre: "Esquina N3", id: "ap:barrera_n3_esquina", precio: 5 },
  // Nivel 4
  { nombre: "Base N4", id: "ap:base_n4", precio: 200 },
  { nombre: "Barrera N4", id: "ap:barrera_n4", precio: 100 },
  { nombre: "Esquina N4", id: "ap:barrera_n4_esquina", precio: 10 }
];

// ==========================================
// 💰 TABLA DE VALORES DE VENTA (PRECIO UNITARIO)
// ==========================================
const PRECIOS_VENTA = {
  // Cultivos y Agricultura (Trigo: 2 items = 50 pts => 25 pts c/u)
  "minecraft:wheat": 25,
  "minecraft:wheat_seeds": 2,
  "minecraft:carrot": 20,
  "minecraft:potato": 20,
  "minecraft:beetroot": 20,
  "minecraft:melon_slice": 15,
  "minecraft:pumpkin": 80,
  "minecraft:sugar_cane": 15,
  "minecraft:hay_block": 225,

  // Minerales e Lingotes (Hierro = 11, Bloque de Hierro = 198)
  "minecraft:coal": 5,
  "minecraft:coal_block": 45,
  "minecraft:raw_iron": 8,
  "minecraft:iron_ingot": 11,
  "minecraft:iron_block": 198,
  "minecraft:raw_copper": 4,
  "minecraft:copper_ingot": 6,
  "minecraft:copper_block": 54,
  "minecraft:raw_gold": 20,
  "minecraft:gold_ingot": 30,
  "minecraft:gold_block": 270,
  "minecraft:redstone": 9,
  "minecraft:redstone_block": 81,
  "minecraft:lapis_lazuli": 12,
  "minecraft:lapis_block": 108,
  "minecraft:quartz": 15,
  "minecraft:quartz_block": 60,
  "minecraft:amethyst_shard": 40,

  // Objetos de Alta Rareza (> 10,000)
  "minecraft:diamond": 10000,
  "minecraft:diamond_block": 90000,
  "minecraft:emerald": 12000,
  "minecraft:emerald_block": 108000,
  "minecraft:netherite_scrap": 8000,
  "minecraft:netherite_ingot": 25000,
  "minecraft:netherite_block": 225000,

  // Alimentos y Comida Encantada
  "minecraft:bread": 50,
  "minecraft:apple": 25,
  "minecraft:cooked_beef": 45,
  "minecraft:cooked_porkchop": 45,
  "minecraft:cooked_chicken": 35,
  "minecraft:cooked_cod": 30,
  "minecraft:cooked_salmon": 35,
  "minecraft:baked_potato": 30,
  "minecraft:golden_apple": 2500,
  "minecraft:enchanted_golden_apple": 15000, // Comida encantada vale el doble o más

  // Drops de Entidades y Criaturas
  "minecraft:rotten_flesh": 3,
  "minecraft:bone": 8,
  "minecraft:string": 6,
  "minecraft:spider_eye": 10,
  "minecraft:gunpowder": 15,
  "minecraft:ender_pearl": 100,
  "minecraft:blaze_rod": 150,
  "minecraft:ghast_tear": 500,
  "minecraft:slime_ball": 25,
  "minecraft:leather": 15,
  "minecraft:feather": 5,
  "minecraft:totem_of_undying": 12000,
  "minecraft:nether_star": 50000,

  // Bloques Vanilla Construcción
  "minecraft:cobblestone": 1,
  "minecraft:stone": 2,
  "minecraft:smooth_stone": 3,
  "minecraft:obsidian": 150,
  "minecraft:crying_obsidian": 300,
  "minecraft:oak_log": 8,
  "minecraft:spruce_log": 8,
  "minecraft:birch_log": 8,
  "minecraft:jungle_log": 8,
  "minecraft:acacia_log": 8,
  "minecraft:dark_oak_log": 8,
  "minecraft:mangrove_log": 8,
  "minecraft:glass": 5,

  // Addon Vallas y Componentes
  "ap:sp_n1_base_valla": 20,
  "ap:sp_n1_base_valla_barrera": 10,
  "ap:sp_n1_base_valla_barrera_esquina": 1,
  "ap:sp_n2_base_valla": 40,
  "ap:sp_n2_base_valla_barrera": 20,
  "ap:sp_n2_base_valla_barrera_esquina": 2,
  "ap:sp_n3_base_valla": 80,
  "ap:sp_n3_base_valla_barrera": 40,
  "ap:sp_n3_base_valla_barrera_esquina": 4,
  "ap:sp_n4_base_valla": 160,
  "ap:sp_n4_base_valla_barrera": 80,
  "ap:sp_n4_base_valla_barrera_esquina": 8
};

// ==========================================
// 🏦 COMPONENTE PERSONALIZADO: CAJA REGISTRADORA
// ==========================================
world.beforeEvents.worldInitialize.subscribe((init) => {
  init.blockComponentRegistry.registerCustomComponent("ap:registro_interact", {
    onPlayerInteract(e) {
      const p = e.player;
      const container = p.getComponent("inventory")?.container;
      if (!container) return;

      const slotIndex = p.selectedSlotIndex;
      const itemEnMano = container.getItem(slotIndex);

      // Si sostiene el panel de operaciones, no interrumpe su lógica
      if (itemEnMano?.typeId === "ap:panel_op") return;

      // 1. Depósito de dinero físico (Minecoins o Billetes)
      if (itemEnMano?.typeId === "ap:minecoin" || itemEnMano?.typeId === "ap:billete") {
        const valorUnidad = itemEnMano.typeId === "ap:minecoin" ? 50 : 1000;
        const totalDeposito = itemEnMano.amount * valorUnidad;

        system.run(() => {
          getDineroObjective().addScore(p, totalDeposito);
          container.setItem(slotIndex, undefined); // Consume la pila
          p.sendMessage({
            rawtext: [
              { text: "§a[BANCO]: Depositados §e$" },
              { text: totalDeposito.toLocaleString() },
              { text: " §aa tu cuenta." }
            ]
          });
          p.playSound("random.orb");
        });
        return;
      }

      // 2. Venta de ítems al sostener un objeto con valor
      if (itemEnMano && PRECIOS_VENTA[itemEnMano.typeId] !== undefined) {
        system.run(() => {
          procesarVentaItem(p, container, slotIndex, itemEnMano);
        });
        return;
      }

      // 3. Si interactúa con la mano vacía o con un objeto no vendible, abre la tienda
      system.run(() => abrirTienda(p));
    }
  });
});

// ==========================================
// 💸 LÓGICA DE VENTA DE OBJETOS
// ==========================================
function procesarVentaItem(p, container, slotIndex, item) {
  const precioUnitario = PRECIOS_VENTA[item.typeId];
  if (!precioUnitario || precioUnitario <= 0) {
    p.sendMessage("§c[CAJA]: Este objeto no tiene valor comercial.");
    return;
  }

  const cantidad = item.amount;
  const pagoTotal = precioUnitario * cantidad;

  // Remueve la pila vendida de la mano del jugador
  container.setItem(slotIndex, undefined);

  // Acredita el dinero en el Scoreboard
  getDineroObjective().addScore(p, pagoTotal);

  const nombreFormateado = item.typeId.replace("minecraft:", "").replace("ap:", "").replace(/_/g, " ");

  p.sendMessage({
    rawtext: [
      { text: "§a[CAJA REGISTRADORA]: Vendido §b" },
      { text: `${cantidad}x ${nombreFormateado}` },
      { text: " §apor §e$" },
      { text: pagoTotal.toLocaleString() },
      { text: " pts." }
    ]
  });
  p.playSound("random.orb");
}

// ==========================================
// 🛒 MENÚS DE TIENDA DE COMPRA
// ==========================================
function abrirTienda(p) {
  new ActionFormData()
    .title({ translate: "ap.title.tienda_recursos" })
    .body("§fSelecciona la categoría de artículos que deseas comprar:")
    .button("💎 Minerales")
    .button("🍖 Alimentos y Comida")
    .button("🚧 Vallas y Estructuras (N1-N4)")
    .show(p).then((r) => {
      if (r.canceled) return;
      if (r.selection === 0) abrirFormularioCategoria(p, CATALOGO_MINERALES, "MINERALES");
      if (r.selection === 1) abrirFormularioCategoria(p, CATALOGO_COMIDA, "ALIMENTOS");
      if (r.selection === 2) abrirFormularioCategoria(p, CATALOGO_VALLAS, "VALLAS DE CONTENCIÓN");
    });
}

function abrirFormularioCategoria(p, listaCatalogo, nombreCategoria) {
  const opciones = listaCatalogo.map(item => `${item.nombre} ($${item.precio.toLocaleString()})`);

  new ModalFormData()
    .title(`TIENDA: ${nombreCategoria}`)
    .dropdown("Selecciona Artículo:", opciones, 0)
    .slider("Cantidad:", 1, 64, 1, 1)
    .show(p).then(r => {
      if (r.canceled) return;

      const itemSeleccionado = listaCatalogo[r.formValues[0]];
      const cantidad = Math.floor(r.formValues[1]);
      const costeTotal = itemSeleccionado.precio * cantidad;

      system.run(() => {
        const objDinero = getDineroObjective();
        let saldoActual = 0;
        try {
          saldoActual = objDinero.getScore(p) ?? 0;
        } catch (err) { }

        const container = p.getComponent("inventory")?.container;

        if (saldoActual < costeTotal) {
          p.sendMessage("§c[TIENDA]: Saldo insuficiente en tu cuenta.");
          p.playSound("note.bass");
          return;
        }

        if (!container || container.emptySlotsCount === 0) {
          p.sendMessage({ translate: "ap.msg.ap_inv" });
          p.playSound("note.bass");
          return;
        }

        // Descuento e inserción de items
        objDinero.addScore(p, -costeTotal);

        try {
          container.addItem(new ItemStack(itemSeleccionado.id, cantidad));
        } catch (e) {
          p.runCommandAsync(`give @s ${itemSeleccionado.id} ${cantidad}`).catch(() => { });
        }

        p.sendMessage({
          rawtext: [
            { text: "§a[TIENDA]: Comprado §b" },
            { text: `${cantidad}x ${itemSeleccionado.nombre}` },
            { text: " §apor §e$" },
            { text: costeTotal.toLocaleString() },
            { text: "." }
          ]
        });
        p.playSound("random.levelup");
      });
    }).catch(() => { });
}
